import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { TrackPath, TRACKS, type TrackDef, type Frame } from "./tracks";
import { buildCar, CAR_MODELS, LIVERIES, PAINTS, defaultSkin3D, type CarRig, type CarSkin3D } from "./carModels";
import { drawItem, ITEMS, type ItemId } from "../game/items";
import type { GhostFrame } from "../game/progress";

export { TRACKS } from "./tracks";
export type GamePhase = "menu" | "intro" | "countdown" | "racing" | "finished";
export type RaceMode = "race" | "item" | "elim" | "time" | "team" | "license";

export const STEP = 1 / 60;
const MAX_SPEED = 78;           // m/s ≈ 281 km/h（氮气可达 ~410 km/h）
const ACCEL = 26;
const BRAKE = -52;
const COAST = -9;
const OFFROAD_DRAG = -26;
const OFFROAD_MAX = 34;
const RIVALS = 7;
const CAR_LEN = 4.6;
const CAR_WID = 2.1;
const MAX_HP = 100;
const HP_REGEN = 7;
const DMG_OBSTACLE = 34;
const DMG_CAR = 7;
const DMG_WALL = 22;

// 漂移 / 组合喷
const DRIFT_MIN = MAX_SPEED * 0.22;
const DRIFT_CHARGE = 46;
const BOOST_MULT = 1.3;
const NOS_T = 1.7;
const MINI_T = 0.7;
const DBL_WINDOW = 0.62;
const DBL_PERFECT = [0.28, 0.62] as const;
const WC_MULT = 1.46;
const LINK_WINDOW = 0.55;
const MAX_CANS = 3;
const COMBO_TTL = 4;
const ELIM_INTERVAL = 20;

const RIVAL_NAMES = ["旋风阿飞", "夜刃", "追光者", "小铁块", "疾风丸", "雷诺", "冰河", "赤兔", "银翼", "游侠"];

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

interface Obstacle { s: number; lat: number; r: number }
interface Racer {
  id: number;              // -1 玩家
  name: string;
  skin: CarSkin3D;
  rig: CarRig;
  s: number;
  lat: number;
  speed: number;
  lap: number;
  dist: number;
  yaw: number;
  targetLat: number;
  skill: number;
  boost: number;
  boostCd: number;
  stun: number;
  shield: number;
  item: ItemId | null;
  itemCd: number;
  out: boolean;
  finished: boolean;
  isTeammate: boolean;
}
interface Dropped { kind: "banana" | "mine"; s: number; lat: number; owner: number; life: number; armed: number; mesh: THREE.Object3D }
interface Missile { s: number; lat: number; target: number; owner: number; life: number; mesh: THREE.Object3D }
interface ItemBox { s: number; lat: number; respawn: number; mesh: THREE.Object3D }
interface Pad { s: number; len: number }
interface Ramp { s: number }

export interface Standing { name: string; lap: number; isPlayer: boolean; isTeammate: boolean; prog: number; color: string; finished: boolean }

export interface Hud3D {
  phase: GamePhase; speedKmh: number; speedPct: number;
  lap: number; totalLaps: number; lapTime: number; lastLap: number | null; bestLap: number | null; totalTime: number;
  hp: number; maxHp: number; hpFlash: number;
  countdown: number; goTimer: number; introT: number;
  drifting: boolean; driftTime: number; charge: number; cans: number; boost: number;
  boostLabel: string; boostSeq: number; combo: number; dblWindow: number; dblPerfect: readonly [number, number];
  wcArmed: boolean; linkReady: boolean; airborne: boolean; offroad: boolean; paused: boolean;
  mode: RaceMode; position: number; totalRacers: number; standings: Standing[];
  teamScore: number; rivalScore: number;
  itemsEnabled: boolean; item: ItemId | null; itemRolling: boolean; itemFlash: string;
  shieldT: number; ghostT: number;
  elimTimer: number; elimWarn: boolean; elimCount: number; eliminated: boolean;
  licenseProgress: number; trackId: string;
  mapPlayer: { x: number; y: number }; mapRivals: { x: number; y: number; teammate: boolean }[];
  mapPath: { x: number; y: number }[];
}

export interface Keys { up: boolean; down: boolean; left: boolean; right: boolean; drift: boolean; nos: boolean; driftTap: boolean; accelTap: boolean }

export class Engine3D {
  renderer: THREE.WebGLRenderer | null = null;
  headless = false;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  keys: Keys = { up: false, down: false, left: false, right: false, drift: false, nos: false, driftTap: false, accelTap: false };

  phase: GamePhase = "menu";
  paused = false;
  mode: RaceMode = "race";
  totalLaps = 3;
  trackId = "coast";
  playerSkin: CarSkin3D = defaultSkin3D();
  playerName = "你";
  tuning = { speed: 1, nitro: 1, grip: 1, accel: 1, frame: 1 };
  itemsEnabled = false;
  licenseGoal: { type: string; count?: number; seconds?: number } | null = null;
  licenseProgress = 0;
  licensePassed = false;
  counters = { drift: 0, mini: 0, double: 0, perfect: 0, wc: 0, link: 0, crashes: 0, cleanTime: 0 };
  roomSeed = 1;
  roomCode = "LOCAL";
  teamNames: string[] = [];
  ghostData: GhostFrame[] | null = null;
  eliminated = false;

  private path!: TrackPath;
  private def!: TrackDef;
  private trackGroup = new THREE.Group();
  private carGroup = new THREE.Group();
  private fxGroup = new THREE.Group();
  private obstacles: Obstacle[] = [];
  private pads: Pad[] = [];
  private ramps: Ramp[] = [];
  private itemBoxes: ItemBox[] = [];
  private dropped: Dropped[] = [];
  private missiles: Missile[] = [];
  private mapPathPts: { x: number; y: number }[] = [];
  private mapBounds = { minX: 0, minY: 0, span: 1 };

  private player!: Racer;
  private rivals: Racer[] = [];
  private ghostRig: CarRig | null = null;
  private ghostRec: GhostFrame[] = [];
  private ghostT2 = 0;
  private recT = 0;

  // 状态
  private hp = MAX_HP;
  private hpFlash = 0;
  private invuln = 0;
  private airY = 0; private airV = 0; private airborne = false; private airTime = 0;
  private drifting = false; private driftDir: -1 | 1 = 1; private driftTime = 0;
  private charge = 0; private cans = 1; private boost = 0; private boostMult = 1;
  private boostTone = "none"; private boostLabel = ""; private boostLabelT = 0; private boostSeq = 0;
  private dblWindow = 0; private wcArmed = false;
  private combo = 0; private comboTimer = 0; private bestCombo = 0;
  private counterCd = 0; private prevSteer = 0;
  private lap = 1; private lapTime = 0; private lastLap: number | null = null; private bestLap: number | null = null;
  private totalTime = 0; private maxSpeedSeen = 0; private lapTimes: number[] = [];
  private countdown = 3; private goTimer = 0; private introT = 0;
  private shieldT = 0; private ghostItemT = 0; private spinT = 0; private magnetT = 0;
  private itemSlot: ItemId | null = null; private itemRoll = 0; private itemFlash = ""; private itemFlashT = 0; private itemsUsed = 0;
  private elimTimer = ELIM_INTERVAL; private elimCount = 0; private elimWarn = false;
  private shake = 0; private padCd = 0; private camShake = new THREE.Vector3();
  private finalStandings: Standing[] = [];
  private finishTime = 0;
  private rng = Math.random;

  private tmpFrame: Frame = { pos: new THREE.Vector3(), tan: new THREE.Vector3(), bin: new THREE.Vector3(), nor: new THREE.Vector3(), curv: 0, bank: 0 };
  private camPos = new THREE.Vector3();
  private camLook = new THREE.Vector3();
  private sun!: THREE.DirectionalLight;
  private hemi!: THREE.HemisphereLight;
  private pmrem: THREE.PMREMGenerator | null = null;

  onCrash: (() => void) | null = null;
  onLap: (() => void) | null = null;
  onFinish: (() => void) | null = null;
  onNos: (() => void) | null = null;
  onMiniBoost: (() => void) | null = null;
  onPerfect: (() => void) | null = null;
  onItemGet: ((i: ItemId) => void) | null = null;
  onItemUse: ((i: ItemId) => void) | null = null;
  onShield: (() => void) | null = null;
  onExplode: (() => void) | null = null;
  onEliminate: ((n: string) => void) | null = null;
  onPad: (() => void) | null = null;
  onLand: ((big: boolean) => void) | null = null;
  onDamage: (() => void) | null = null;

  constructor(canvas: HTMLCanvasElement | null) {
    this.headless = !canvas;
    if (canvas) {
      this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
      this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
      this.renderer.outputColorSpace = THREE.SRGBColorSpace;
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.05;
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    }

    this.camera = new THREE.PerspectiveCamera(70, 16 / 9, 0.4, 4000);
    this.scene.add(this.trackGroup, this.carGroup, this.fxGroup);

    if (this.renderer) {
      this.pmrem = new THREE.PMREMGenerator(this.renderer);
      this.scene.environment = this.pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    }

    this.sun = new THREE.DirectionalLight(0xffffff, 2.4);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(1024, 1024);
    this.sun.shadow.camera.near = 1;
    this.sun.shadow.camera.far = 260;
    const sc = this.sun.shadow.camera as THREE.OrthographicCamera;
    sc.left = -60; sc.right = 60; sc.top = 60; sc.bottom = -60;
    this.scene.add(this.sun, this.sun.target);
    this.hemi = new THREE.HemisphereLight(0xffffff, 0x404060, 1.5);
    this.scene.add(this.hemi);

    this.setTrack("coast");
  }

  resize(w: number, h: number) {
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer?.setSize(w, h, false);
  }

  dispose() {
    this.renderer?.dispose();
    this.pmrem?.dispose();
  }

  // ================================================================ 赛道构建
  setTrack(id: string) {
    const def = TRACKS.find((t) => t.id === id) ?? TRACKS[0];
    this.def = def;
    this.trackId = def.id;
    this.path = new TrackPath(def);
    this.buildScene();
    this.buildMap();
    if (this.phase !== "menu") this.phase = "menu";
    this.resetRacers();
  }

  private disposeGroup(g: THREE.Group) {
    g.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
      const mat = m.material as THREE.Material | THREE.Material[];
      if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
      else if (mat) mat.dispose();
    });
    g.clear();
  }

  private buildScene() {
    this.disposeGroup(this.trackGroup);
    const th = this.def.theme;
    const P = this.path;
    const N = P.samples;
    const HW = th.roadWidth / 2;

    this.scene.fog = new THREE.FogExp2(new THREE.Color(th.fog).getHex(), th.fogDensity);
    this.scene.background = this.headless ? new THREE.Color(th.sky[1]) : this.makeSky(th.sky);
    this.sun.color.set(th.sun);
    this.sun.intensity = th.sunIntensity;
    this.hemi.color.set(th.sun);
    this.hemi.groundColor.set(th.ground);
    this.hemi.intensity = th.ambientIntensity;

    // ---------- 地面
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(4000, 4000),
      new THREE.MeshStandardMaterial({ color: th.ground, roughness: 0.95, metalness: 0 }),
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -1.2;
    ground.receiveShadow = true;
    this.trackGroup.add(ground);

    // ---------- 路面（含路肩）
    const roadPos: number[] = [];
    const roadUv: number[] = [];
    const roadIdx: number[] = [];
    const shPos: number[] = [];
    const shIdx: number[] = [];
    const shColor: number[] = [];
    const cA = new THREE.Color(th.rumbleA);
    const cB = new THREE.Color(th.rumbleB);
    const SHW = 1.1;

    for (let i = 0; i <= N; i++) {
      const f = P.frames[i % N];
      const l = f.pos.clone().addScaledVector(f.bin, -HW).addScaledVector(f.nor, 0.02);
      const r = f.pos.clone().addScaledVector(f.bin, HW).addScaledVector(f.nor, 0.02);
      roadPos.push(l.x, l.y, l.z, r.x, r.y, r.z);
      const v = (i / N) * (P.length / 12);
      roadUv.push(0, v, 1, v);
      // 路肩
      const l2 = f.pos.clone().addScaledVector(f.bin, -HW - SHW).addScaledVector(f.nor, -0.02);
      const r2 = f.pos.clone().addScaledVector(f.bin, HW + SHW).addScaledVector(f.nor, -0.02);
      shPos.push(l2.x, l2.y, l2.z, l.x, l.y, l.z, r.x, r.y, r.z, r2.x, r2.y, r2.z);
      const c = (Math.floor(i / 4) % 2 ? cA : cB);
      for (let k = 0; k < 4; k++) shColor.push(c.r, c.g, c.b);
      if (i < N) {
        const a = i * 2;
        roadIdx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
        const b = i * 4;
        shIdx.push(b, b + 1, b + 4, b + 1, b + 5, b + 4);       // 左路肩
        shIdx.push(b + 2, b + 3, b + 6, b + 3, b + 7, b + 6);   // 右路肩
      }
    }
    const roadGeo = new THREE.BufferGeometry();
    roadGeo.setAttribute("position", new THREE.Float32BufferAttribute(roadPos, 3));
    roadGeo.setAttribute("uv", new THREE.Float32BufferAttribute(roadUv, 2));
    roadGeo.setIndex(roadIdx);
    roadGeo.computeVertexNormals();
    const road = new THREE.Mesh(roadGeo, new THREE.MeshStandardMaterial({
      ...(this.headless ? {} : { map: this.roadTexture(th.road, th.night) }), color: th.road, roughness: 0.72, metalness: 0.08,
    }));
    road.receiveShadow = true;
    this.trackGroup.add(road);

    const shGeo = new THREE.BufferGeometry();
    shGeo.setAttribute("position", new THREE.Float32BufferAttribute(shPos, 3));
    shGeo.setAttribute("color", new THREE.Float32BufferAttribute(shColor, 3));
    shGeo.setIndex(shIdx);
    shGeo.computeVertexNormals();
    this.trackGroup.add(new THREE.Mesh(shGeo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.7 })));

    // ---------- 护栏（硬边界）
    const railH = 1.25;
    const RW = HW + 8;
    for (const side of [-1, 1]) {
      const gp: number[] = [];
      const gi: number[] = [];
      for (let i = 0; i <= N; i++) {
        const f = P.frames[i % N];
        const base = f.pos.clone().addScaledVector(f.bin, side * RW);
        const top = base.clone().addScaledVector(f.nor, railH);
        gp.push(base.x, base.y, base.z, top.x, top.y, top.z);
        if (i < N) { const a = i * 2; gi.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
      }
      const gg = new THREE.BufferGeometry();
      gg.setAttribute("position", new THREE.Float32BufferAttribute(gp, 3));
      gg.setIndex(gi);
      gg.computeVertexNormals();
      this.trackGroup.add(new THREE.Mesh(gg, new THREE.MeshStandardMaterial({
        color: th.guard, roughness: 0.35, metalness: 0.85, side: THREE.DoubleSide,
        emissive: th.guardEmissive, emissiveIntensity: th.night ? 0.55 : 0.12,
      })));
    }

    // ---------- 加速带 / 跳台 / 障碍 / 道具箱
    this.rng = this.makeRng(this.roomSeed * 977 + this.trackId.length * 31);
    this.pads = [];
    this.ramps = [];
    this.obstacles = [];
    this.itemBoxes = [];
    const L = P.length;

    // 加速带：直道段
    for (let s = 60; s < L - 60; s += 14) {
      const f = P.frameAt(s, this.tmpFrame);
      if (Math.abs(f.curv) < 1.2 && this.rng() < 0.1) {
        this.pads.push({ s, len: 16 });
        const padMesh = this.ribbon(s, 16, HW * 0.62, 0.06, new THREE.MeshBasicMaterial({
          color: th.night ? "#22d3ee" : "#38bdf8", transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false,
        }));
        this.trackGroup.add(padMesh);
        s += 90;
      }
    }
    // 跳台：5~6 处
    const rampCount = 5 + (this.rng() < 0.5 ? 0 : 1);
    for (let k = 0; k < rampCount; k++) {
      const s = ((k + 0.5) / rampCount) * L + (this.rng() - 0.5) * L * 0.06;
      this.ramps.push({ s });
      const f = P.frameAt(s, this.tmpFrame);
      const ramp = new THREE.Mesh(
        new THREE.BoxGeometry(HW * 1.9, 0.55, 9),
        new THREE.MeshStandardMaterial({ color: "#ffd23f", roughness: 0.5, metalness: 0.3, emissive: "#c98a00", emissiveIntensity: 0.35 }),
      );
      ramp.position.copy(f.pos).addScaledVector(f.nor, 0.18);
      ramp.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(f.bin, f.nor, f.tan.clone().negate()));
      ramp.rotateX(0.14);
      ramp.castShadow = true;
      this.trackGroup.add(ramp);
    }
    // 缓冲区障碍物（撞到扣血）
    const decoInst = this.buildDecor(th.decor, th.decorColor);
    let placed = 0;
    const mtx = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const scl = new THREE.Vector3();
    for (let s = 20; s < L - 20 && placed < 520; s += 9 + this.rng() * 11) {
      for (const side of [-1, 1]) {
        if (this.rng() > 0.62) continue;
        const lat = side * (HW + 2.6 + this.rng() * 5.0);
        const f = P.frameAt(s, this.tmpFrame);
        const p = f.pos.clone().addScaledVector(f.bin, lat);
        const sz = 0.8 + this.rng() * 0.55;
        q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), this.rng() * 6.28);
        scl.set(sz, sz * (0.85 + this.rng() * 0.5), sz);
        mtx.compose(p, q, scl);
        decoInst.setMatrixAt(placed, mtx);
        this.obstacles.push({ s, lat, r: 1.5 * sz });
        placed++;
        if (placed >= 520) break;
      }
    }
    decoInst.count = placed;
    decoInst.instanceMatrix.needsUpdate = true;
    decoInst.castShadow = true;
    this.trackGroup.add(decoInst);

    // 道具箱
    for (let s = 70; s < L - 40; s += 95) {
      const lanes = this.rng() < 0.5 ? [-HW * 0.55, 0, HW * 0.55] : [this.rng() < 0.5 ? -HW * 0.4 : HW * 0.4];
      for (const lat of lanes) {
        const mesh = this.makeItemBox();
        const f = P.frameAt(s, this.tmpFrame);
        mesh.position.copy(f.pos).addScaledVector(f.bin, lat).addScaledVector(f.nor, 1.3);
        this.fxGroup.add(mesh);
        this.itemBoxes.push({ s, lat, respawn: 0, mesh });
      }
    }

    // ---------- 起点门 + 发光拱门
    this.addGate(0, HW, th.guardEmissive);
    for (let k = 1; k < 5; k++) this.addGate((k / 5) * L, HW, th.guardEmissive);

    // ---------- 路灯（夜景）
    if (th.night) {
      for (let s = 0; s < L; s += 42) {
        const f = P.frameAt(s, this.tmpFrame);
        for (const side of [-1, 1]) {
          const pole = new THREE.Mesh(
            new THREE.CylinderGeometry(0.12, 0.16, 6.5, 6),
            new THREE.MeshStandardMaterial({ color: "#2b2f3d", metalness: 0.8, roughness: 0.4 }),
          );
          pole.position.copy(f.pos).addScaledVector(f.bin, side * (HW + 1.9)).addScaledVector(f.nor, 3.2);
          this.trackGroup.add(pole);
          const bulb = new THREE.Mesh(
            new THREE.SphereGeometry(0.42, 10, 8),
            new THREE.MeshBasicMaterial({ color: th.guardEmissive }),
          );
          bulb.position.copy(f.pos).addScaledVector(f.bin, side * (HW + 1.9)).addScaledVector(f.nor, 6.5);
          this.trackGroup.add(bulb);
        }
      }
    }
  }

  private makeSky(cols: [string, string, string]) {
    const cv = document.createElement("canvas");
    cv.width = 16; cv.height = 256;
    const c = cv.getContext("2d")!;
    const g = c.createLinearGradient(0, 0, 0, 256);
    g.addColorStop(0, cols[0]); g.addColorStop(0.55, cols[1]); g.addColorStop(1, cols[2]);
    c.fillStyle = g; c.fillRect(0, 0, 16, 256);
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.mapping = THREE.EquirectangularReflectionMapping;
    return tex;
  }

  private roadTexture(base: string, night: boolean) {
    const cv = document.createElement("canvas");
    cv.width = 128; cv.height = 128;
    const c = cv.getContext("2d")!;
    c.fillStyle = base; c.fillRect(0, 0, 128, 128);
    for (let i = 0; i < 900; i++) {
      c.fillStyle = `rgba(255,255,255,${Math.random() * 0.05})`;
      c.fillRect(Math.random() * 128, Math.random() * 128, 2, 2);
    }
    // 中线虚线
    c.fillStyle = night ? "#dbeafe" : "#f1f5f9";
    c.fillRect(62, 0, 5, 62);
    const tex = new THREE.CanvasTexture(cv);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(1, 1);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return tex;
  }

  private ribbon(s0: number, len: number, halfW: number, h: number, mat: THREE.Material) {
    const P = this.path;
    const pos: number[] = [];
    const idx: number[] = [];
    const steps = 8;
    for (let i = 0; i <= steps; i++) {
      const f = P.frameAt(s0 + (i / steps) * len, this.tmpFrame);
      const l = f.pos.clone().addScaledVector(f.bin, -halfW).addScaledVector(f.nor, h);
      const r = f.pos.clone().addScaledVector(f.bin, halfW).addScaledVector(f.nor, h);
      pos.push(l.x, l.y, l.z, r.x, r.y, r.z);
      if (i < steps) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    g.setIndex(idx);
    g.computeVertexNormals();
    return new THREE.Mesh(g, mat);
  }

  private buildDecor(kind: string, color: string) {
    let geo: THREE.BufferGeometry;
    let mat: THREE.Material;
    if (kind === "palm") {
      geo = new THREE.ConeGeometry(1.5, 5.5, 7);
      mat = new THREE.MeshStandardMaterial({ color, roughness: 0.8 });
    } else if (kind === "pine") {
      geo = new THREE.ConeGeometry(1.7, 6.5, 8);
      mat = new THREE.MeshStandardMaterial({ color, roughness: 0.85 });
    } else if (kind === "cactus") {
      geo = new THREE.CapsuleGeometry(0.6, 3.2, 4, 8);
      mat = new THREE.MeshStandardMaterial({ color, roughness: 0.75 });
    } else {
      geo = new THREE.IcosahedronGeometry(1.5, 0);
      mat = new THREE.MeshStandardMaterial({ color, roughness: 0.3, metalness: 0.7, emissive: color, emissiveIntensity: 0.5 });
    }
    return new THREE.InstancedMesh(geo, mat, 520);
  }

  private makeItemBox() {
    const g = new THREE.Group();
    const box = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.85, 0),
      new THREE.MeshStandardMaterial({ color: "#ffd166", emissive: "#ff9f1c", emissiveIntensity: 1.1, metalness: 0.6, roughness: 0.25, transparent: true, opacity: 0.92 }),
    );
    g.add(box);
    const halo = new THREE.Mesh(
      new THREE.TorusGeometry(1.1, 0.07, 8, 24),
      new THREE.MeshBasicMaterial({ color: "#fff3b0", transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false }),
    );
    halo.rotation.x = Math.PI / 2;
    g.add(halo);
    g.userData.spin = box;
    return g;
  }

  private addGate(s: number, hw: number, glow: string) {
    const f = this.path.frameAt(s, this.tmpFrame);
    const g = new THREE.Group();
    const matP = new THREE.MeshStandardMaterial({ color: "#20232e", metalness: 0.85, roughness: 0.3 });
    const matG = new THREE.MeshStandardMaterial({ color: glow, emissive: glow, emissiveIntensity: 1.6, metalness: 0.5, roughness: 0.3 });
    for (const side of [-1, 1]) {
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.7, 9, 0.7), matP);
      p.position.set(side * (hw + 1.6), 4.5, 0);
      g.add(p);
    }
    const beam = new THREE.Mesh(new THREE.BoxGeometry((hw + 2) * 2, 1.2, 0.8), matG);
    beam.position.y = 8.6;
    g.add(beam);
    g.position.copy(f.pos);
    g.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(f.bin, f.nor, f.tan.clone().negate()));
    this.trackGroup.add(g);
  }

  private buildMap() {
    const P = this.path;
    const pts: { x: number; y: number }[] = [];
    for (let i = 0; i < P.samples; i += Math.max(1, Math.floor(P.samples / 160))) {
      pts.push({ x: P.frames[i].pos.x, y: P.frames[i].pos.z });
    }
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const p of pts) { minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x); minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y); }
    const span = Math.max(maxX - minX, maxY - minY) || 1;
    this.mapBounds = { minX, minY, span };
    const sc = 0.86 / span;
    const ox = (1 - (maxX - minX) * sc) / 2;
    const oy = (1 - (maxY - minY) * sc) / 2;
    this.mapPathPts = pts.map((p) => ({ x: ox + (p.x - minX) * sc, y: oy + (p.y - minY) * sc }));
  }

  private mapOf(s: number) {
    const f = this.path.frameAt(s, this.tmpFrame);
    const { minX, minY, span } = this.mapBounds;
    const sc = 0.86 / span;
    const bx = (1 - (span) * sc) / 2;
    return { x: bx + (f.pos.x - minX) * sc + 0.07, y: bx + (f.pos.z - minY) * sc + 0.07 };
  }

  private makeRng(seed: number) {
    let x = (seed >>> 0) || 1;
    return () => { x ^= x << 13; x ^= x >>> 17; x ^= x << 5; x >>>= 0; return x / 4294967296; };
  }

  // ================================================================ 车手
  setSkin(s: CarSkin3D) {
    this.playerSkin = s;
    if (this.player) {
      this.carGroup.remove(this.player.rig.group);
      this.player.rig = buildCar(s);
      this.player.skin = s;
      this.carGroup.add(this.player.rig.group);
    }
  }
  setMode(m: RaceMode) { this.mode = m; }
  setLaps(n: number) { this.totalLaps = n; }
  setRoom(seed: number, mates: string[], code = "LOCAL") {
    const changed = this.roomSeed !== (seed || 1);
    this.roomSeed = seed || 1; this.teamNames = mates; this.roomCode = code;
    if (changed && this.phase === "menu") { this.buildScene(); this.resetRacers(); }
  }

  private randSkin(r: () => number): CarSkin3D {
    const p = PAINTS[Math.floor(r() * PAINTS.length)];
    return { model: CAR_MODELS[Math.floor(r() * CAR_MODELS.length)], paintA: p.a, paintB: p.b, livery: LIVERIES[Math.floor(r() * LIVERIES.length)].id };
  }

  private resetRacers() {
    this.disposeGroup(this.carGroup);
    const mkRacer = (id: number, name: string, skin: CarSkin3D, isTeammate: boolean): Racer => {
      const rig = buildCar(skin, { headlights: this.def.theme.night });
      this.carGroup.add(rig.group);
      return {
        id, name, skin, rig, s: 0, lat: 0, speed: 0, lap: 1, dist: 0, yaw: 0, targetLat: 0,
        skill: 1, boost: 0, boostCd: 0, stun: 0, shield: 0, item: null, itemCd: 0,
        out: false, finished: false, isTeammate,
      };
    };
    this.player = mkRacer(-1, this.playerName, this.playerSkin, true);
    this.rivals = [];
    if (this.mode !== "time" && this.mode !== "license") {
      const r = this.makeRng(this.roomSeed + 7717);
      const names = [...RIVAL_NAMES];
      for (let i = 0; i < RIVALS; i++) {
        const isMate = this.mode === "team" && i < this.teamNames.length;
        const nm = isMate ? this.teamNames[i] : names.splice(Math.floor(r() * names.length), 1)[0] ?? `车手${i + 1}`;
        const rv = mkRacer(i, nm, this.randSkin(r), isMate);
        rv.skill = 0.88 + r() * 0.26;
        rv.boostCd = 2 + r() * 4;
        this.rivals.push(rv);
      }
    }
    // 幽灵车
    if (this.ghostRig) { this.carGroup.remove(this.ghostRig.group); this.ghostRig = null; }
    if (this.ghostData && this.ghostData.length > 2) {
      this.ghostRig = buildCar({ ...this.playerSkin, paintA: "#9ad9ff", paintB: "#e0f2ff", livery: "solid" });
      this.ghostRig.group.traverse((o) => {
        const mm = (o as THREE.Mesh).material as THREE.Material | undefined;
        if (mm && "transparent" in mm) { (mm as THREE.Material).transparent = true; (mm as any).opacity = 0.35; }
      });
      this.carGroup.add(this.ghostRig.group);
    }
    this.gridPositions();
  }

  private gridPositions() {
    const HW = this.def.theme.roadWidth / 2;
    const all = [this.player, ...this.rivals];
    all.forEach((r, i) => {
      const row = Math.floor(i / 2);
      const col = i % 2 === 0 ? -1 : 1;
      r.s = this.path.length - row * 7 - 6;
      r.lat = col * HW * 0.42;
      r.speed = 0;
      r.lap = 1;
      r.dist = 0;
      r.yaw = 0;
      r.out = false;
      r.finished = false;
      r.stun = 0; r.shield = 0; r.item = null; r.boost = 0;
      this.placeCar(r, 0);
    });
  }

  private placeCar(r: Racer, airH: number) {
    const f = this.path.frameAt(r.s, this.tmpFrame);
    r.rig.group.position.copy(f.pos).addScaledVector(f.bin, r.lat).addScaledVector(f.nor, airH);
    const fwd = f.tan.clone().applyAxisAngle(f.nor, r.yaw);
    const m = new THREE.Matrix4().makeBasis(
      new THREE.Vector3().crossVectors(f.nor, fwd).normalize().negate(),
      f.nor,
      fwd.clone().negate(),
    );
    r.rig.group.quaternion.setFromRotationMatrix(m);
  }

  // ================================================================ 生命周期
  start() {
    this.itemsEnabled = this.mode === "item" || this.mode === "elim";
    this.resetRacers();
    this.hp = MAX_HP; this.hpFlash = 0; this.invuln = 0;
    this.airY = 0; this.airV = 0; this.airborne = false; this.airTime = 0;
    this.drifting = false; this.driftTime = 0; this.charge = 0; this.cans = 1;
    this.boost = 0; this.boostMult = 1; this.boostTone = "none"; this.boostLabel = ""; this.boostLabelT = 0;
    this.dblWindow = 0; this.wcArmed = false; this.combo = 0; this.comboTimer = 0; this.bestCombo = 0;
    this.counterCd = 0; this.prevSteer = 0;
    this.lap = 1; this.lapTime = 0; this.lastLap = null; this.bestLap = null; this.lapTimes = [];
    this.totalTime = 0; this.maxSpeedSeen = 0; this.finishTime = 0;
    this.countdown = 3; this.goTimer = 0; this.introT = 3.6;
    this.shieldT = 0; this.ghostItemT = 0; this.spinT = 0; this.magnetT = 0;
    this.itemSlot = null; this.itemRoll = 0; this.itemFlash = ""; this.itemFlashT = 0; this.itemsUsed = 0;
    this.elimTimer = ELIM_INTERVAL + 10; this.elimCount = 0; this.elimWarn = false; this.eliminated = false;
    this.licenseProgress = 0; this.licensePassed = false;
    this.counters = { drift: 0, mini: 0, double: 0, perfect: 0, wc: 0, link: 0, crashes: 0, cleanTime: 0 };
    this.ghostRec = []; this.ghostT2 = 0; this.recT = 0;
    this.dropped.forEach((d) => this.fxGroup.remove(d.mesh));
    this.missiles.forEach((m) => this.fxGroup.remove(m.mesh));
    this.dropped = []; this.missiles = [];
    this.itemBoxes.forEach((b) => { b.respawn = 0; b.mesh.visible = true; });
    this.finalStandings = [];
    this.paused = false;
    this.phase = "intro";
  }

  backToMenu() { this.phase = "menu"; this.paused = false; }
  togglePause() {
    if (this.phase !== "racing" && this.phase !== "countdown") return;
    this.paused = !this.paused;
    if (this.paused) this.keys = { up: false, down: false, left: false, right: false, drift: false, nos: false, driftTap: false, accelTap: false };
  }
  pause() { if (!this.paused) this.togglePause(); }

  // ================================================================ 更新
  update(dt: number) {
    if (this.paused) return;
    this.animateFx(dt);

    if (this.phase === "menu") { this.menuCam(dt); return; }
    if (this.phase === "intro") {
      this.introT -= dt;
      this.introCam();
      if (this.introT <= 0) { this.phase = "countdown"; this.countdown = 3; }
      return;
    }
    if (this.phase === "countdown") {
      this.countdown -= dt;
      this.chaseCam(dt, true);
      if (this.countdown <= 0) {
        this.phase = "racing";
        this.goTimer = 1.2;
        if (this.keys.up) { this.applyBoost(1.25, 1.32, "起步喷!", "nos"); this.onNos?.(); }
      }
      return;
    }
    if (this.phase === "finished") {
      this.player.speed = Math.max(0, this.player.speed + COAST * dt);
      this.player.s += this.player.speed * dt;
      this.placeCar(this.player, this.airY);
      this.updateRivals(dt);
      this.chaseCam(dt, false);
      return;
    }

    // ===== racing =====
    this.totalTime += dt;
    this.lapTime += dt;
    this.goTimer = Math.max(0, this.goTimer - dt);
    this.counters.cleanTime += dt;
    this.updatePlayer(dt);
    this.updateRivals(dt);
    this.resolveCollisions(dt);
    this.updateItems(dt);
    this.updateGhost(dt);
    this.updateElim(dt);
    this.checkLicense();
    this.chaseCam(dt, false);

    // 幽灵录制
    this.recT += dt;
    if (this.recT >= 0.14 && this.ghostRec.length < 2600) {
      this.recT = 0;
      this.ghostRec.push({ t: Math.round(this.totalTime * 100) / 100, z: Math.round(this.player.dist), x: Math.round(this.player.lat * 100) / 100 });
    }
  }

  private updatePlayer(dt: number) {
    const p = this.player;
    const P = this.path;
    const HW = this.def.theme.roadWidth / 2;
    const f = P.frameAt(p.s, this.tmpFrame);
    const steer = (this.keys.left ? -1 : 0) + (this.keys.right ? 1 : 0);
    const spd = p.speed / MAX_SPEED;

    this.padCd = Math.max(0, this.padCd - dt);
    this.counterCd = Math.max(0, this.counterCd - dt);
    this.hpFlash = Math.max(0, this.hpFlash - dt * 2.5);
    this.invuln = Math.max(0, this.invuln - dt);
    this.shake = Math.max(0, this.shake - dt * 2);
    if (this.boostLabelT > 0) this.boostLabelT -= dt;
    if (this.dblWindow > 0) this.dblWindow = Math.max(0, this.dblWindow - dt);
    if (this.comboTimer > 0) { this.comboTimer -= dt; if (this.comboTimer <= 0) this.combo = 0; }
    this.spinT = Math.max(0, this.spinT - dt);
    this.magnetT = Math.max(0, this.magnetT - dt);

    // ---- 双喷判定
    const dTap = this.keys.driftTap; const aTap = this.keys.accelTap;
    this.keys.driftTap = false; this.keys.accelTap = false;
    let consumed = false;
    if ((dTap || aTap) && this.dblWindow > 0) { this.tryDouble(); consumed = dTap; }

    // ---- 拉头
    if (this.drifting && steer !== 0 && steer === -this.driftDir && this.prevSteer !== steer && this.counterCd <= 0) {
      this.counterCd = 0.3;
      p.lat -= this.driftDir * 0.5;
      this.charge = Math.min(100, this.charge + 14);
      if (this.charge >= 100) { this.charge -= 100; this.cans = Math.min(MAX_CANS, this.cans + 1); }
    }
    this.prevSteer = steer;

    const offroad = Math.abs(p.lat) > HW && !this.airborne;

    // ---- 漂移开关
    if (!this.drifting && this.keys.drift && !consumed && steer !== 0 && p.speed > DRIFT_MIN && !offroad) {
      this.drifting = true; this.driftDir = steer as -1 | 1; this.driftTime = 0; this.counters.drift++;
    }
    if (this.drifting) {
      this.driftTime += dt;
      if (!this.keys.drift || p.speed < DRIFT_MIN * 0.55) this.endDrift(!offroad);
      else if (offroad && spd < 0.4) this.endDrift(false);
    }

    // ---- 横向运动
    const grip = this.tuning.grip * (0.82 + p.skin.model.stats.grip * 0.06);
    const centri = f.curv * spd * 0.42 / grip;
    const steerRate = (this.drifting ? 15 : 9.5) * Math.min(1, spd * 2.2);
    if (this.drifting) {
      const sdir = steer !== 0 ? steer : this.driftDir;
      p.lat += sdir * steerRate * dt;
      p.lat -= centri * dt * (steer === this.driftDir ? 0.3 : 0.7);
      this.charge += dt * DRIFT_CHARGE;
      if (this.charge >= 100) { this.charge -= 100; this.cans = Math.min(MAX_CANS, this.cans + 1); }
      p.yaw = lerp(p.yaw, this.driftDir * (0.28 + 0.14 * Math.min(1, this.driftTime * 2)) - steer * 0.08, dt * 9);
    } else {
      p.lat += steer * steerRate * dt;
      p.lat -= centri * dt;
      p.yaw = lerp(p.yaw, steer * 0.09 + (this.spinT > 0 ? Math.sin(this.spinT * 20) * 0.6 : 0), dt * 8);
    }

    // ---- 氮气键
    if (this.keys.nos) { this.keys.nos = false; this.useNitro(); }

    // ---- 纵向
    const cap = MAX_SPEED * this.tuning.speed * (0.94 + p.skin.model.stats.speed * 0.024) * (this.boost > 0 ? this.boostMult : 1);
    if (this.boost > 0) {
      this.boost -= dt;
      if (this.boost <= 0) { this.boost = 0; this.boostMult = 1; this.boostTone = "none"; }
      p.speed = Math.min(p.speed + 62 * dt, cap);
      this.shake = Math.max(this.shake, 0.12);
    } else if (this.keys.up) p.speed += ACCEL * this.tuning.accel * (0.85 + p.skin.model.stats.accel * 0.06) * dt;
    else if (this.keys.down) p.speed += BRAKE * dt;
    else p.speed += COAST * dt;

    if (this.drifting && this.boost <= 0) p.speed += COAST * 0.6 * dt;
    if (this.spinT > 0) p.speed += COAST * 1.6 * dt;
    if (this.magnetT > 0) p.speed = Math.min(cap * 1.1, p.speed + 34 * dt);

    // ---- 缓冲区（草地/沙地）
    if (offroad) {
      if (p.speed > OFFROAD_MAX) p.speed += OFFROAD_DRAG * dt;
      p.lat += Math.sin(this.totalTime * 11) * dt * 0.7;
    }
    if (p.speed > cap) p.speed = Math.max(cap, p.speed + COAST * 2.4 * dt);
    p.speed = clamp(p.speed, 0, MAX_SPEED * WC_MULT);
    this.maxSpeedSeen = Math.max(this.maxSpeedSeen, p.speed);

    // ---- 加速带
    if (!this.airborne && !offroad && this.padCd <= 0) {
      for (const pad of this.pads) {
        if (Math.abs(P.delta(p.s, pad.s)) < pad.len / 2 && Math.abs(p.lat) < HW * 0.62) {
          this.padCd = 0.7;
          this.applyBoost(0.9, 1.32, "加速带!", "nos");
          this.onPad?.();
          break;
        }
      }
    }
    // ---- 跳台
    if (!this.airborne && !offroad && spd > 0.25) {
      for (const rp of this.ramps) {
        if (Math.abs(P.delta(p.s, rp.s)) < 5) {
          this.airborne = true;
          this.airV = 9 + spd * 9;
          this.airTime = 0;
          this.endDrift(true);
          break;
        }
      }
    }
    if (this.airborne) {
      this.airTime += dt;
      this.airV -= 24 * dt;
      this.airY += this.airV * dt;
      p.yaw = lerp(p.yaw, 0, dt * 3);
      if (this.airY <= 0) {
        this.airY = 0; this.airborne = false;
        const big = this.airTime > 0.75;
        if (this.keys.up) {
          this.applyBoost(big ? 1.05 : 0.75, big ? 1.4 : 1.28, big ? "完美落地喷!!" : "落地喷!", big ? "perfect" : "nos");
          if (big) this.onPerfect?.(); else this.onMiniBoost?.();
        }
        this.shake = Math.max(this.shake, big ? 0.7 : 0.35);
        this.onLand?.(big);
      }
    }

    // ---- 前进
    p.s += p.speed * dt;
    p.dist += p.speed * dt;

    // ---- 护栏硬边界
    const WALL = HW + 7.6;
    if (Math.abs(p.lat) > WALL) {
      p.lat = Math.sign(p.lat) * WALL;
      if (this.invuln <= 0 && p.speed > 12) {
        this.damage(DMG_WALL * dt * 3, "撞上护栏");
        p.speed *= 0.985;
      }
    }

    // ---- 障碍物碰撞（缓冲区）
    if (!this.airborne && this.ghostItemT <= 0 && offroad) {
      for (const ob of this.obstacles) {
        if (Math.abs(P.delta(p.s, ob.s)) > 3.2) continue;
        if (Math.abs(ob.lat - p.lat) > ob.r + CAR_WID * 0.45) continue;
        // 命中
        p.speed *= 0.42;
        p.lat += Math.sign(p.lat - ob.lat || 1) * 1.6;
        this.endDrift(false);
        this.boost = 0; this.boostMult = 1;
        this.damage(DMG_OBSTACLE, "撞上障碍物");
        break;
      }
    }

    // ---- 血量回复
    if (!offroad && this.hp < MAX_HP) this.hp = Math.min(MAX_HP, this.hp + HP_REGEN * dt);

    this.placeCar(p, this.airY);
    this.animateRig(p, dt, this.keys.down);

    // ---- 圈数
    const laps = Math.floor(p.dist / P.length) + 1;
    if (laps > this.lap && this.lapTime > 2) {
      this.lastLap = this.lapTime;
      this.lapTimes.push(this.lapTime);
      if (this.bestLap === null || this.lapTime < this.bestLap) this.bestLap = this.lapTime;
      this.lapTime = 0;
      this.lap = laps;
      if (this.lap > this.totalLaps) this.finish();
      else this.onLap?.();
    }
  }

  private damage(amount: number, reason: string) {
    if (this.invuln > 0 || this.ghostItemT > 0) return;
    this.hp -= amount;
    this.hpFlash = 1;
    this.shake = Math.max(this.shake, Math.min(0.9, amount / 40));
    this.counters.crashes++;
    this.counters.cleanTime = 0;
    this.onDamage?.();
    if (this.hp <= 0) {
      this.hp = MAX_HP * 0.6;
      this.invuln = 2.2;
      this.player.lat = 0;
      this.player.speed = MAX_SPEED * 0.22;
      this.player.yaw = 0;
      this.airborne = false; this.airY = 0;
      this.flashItem("💥 车辆损毁，已回到赛道");
      this.onCrash?.();
    } else {
      this.flashItem(`⚠ ${reason} -${Math.round(amount)}`);
    }
  }

  private updateRivals(dt: number) {
    const P = this.path;
    const HW = this.def.theme.roadWidth / 2;
    for (const r of this.rivals) {
      if (r.out || r.finished) continue;
      r.stun = Math.max(0, r.stun - dt);
      r.shield = Math.max(0, r.shield - dt);
      const f = P.frameAt(r.s, this.tmpFrame);
      const curveFactor = 1 - Math.min(0.44, Math.abs(f.curv) * 0.055 * (2 - r.skill));
      let target = MAX_SPEED * 0.94 * r.skill * curveFactor;
      r.boostCd -= dt;
      if (r.boost > 0) { r.boost -= dt; target *= 1.3; }
      else if (r.boostCd <= 0 && Math.abs(f.curv) < 1.6) { r.boost = 1.1 + this.rng() * 0.7; r.boostCd = 6 + this.rng() * 6; }
      if (r.stun > 0) target *= 0.34;
      const diff = this.player.dist - r.dist;
      target *= clamp(1 + diff / 3200, 0.92, 1.12);
      r.speed += (target - r.speed) * Math.min(1, dt * 1.7);

      // 走线：抱内线 + 躲障碍
      r.targetLat = clamp(-f.curv * 1.1, -HW * 0.66, HW * 0.66);
      r.lat += (r.targetLat - r.lat) * Math.min(1, dt * 1.3);
      r.lat = clamp(r.lat, -HW * 0.92, HW * 0.92);
      r.yaw = lerp(r.yaw, clamp(-f.curv * 0.05, -0.3, 0.3), dt * 5);

      r.s += r.speed * dt;
      r.dist += r.speed * dt;
      if (Math.floor(r.dist / P.length) + 1 > this.totalLaps) { r.finished = true; }
      this.placeCar(r, 0);
      this.animateRig(r, dt, false);
    }
  }

  /** 刚体分离：多次迭代求解，保证任意两车不重叠 → 彻底杜绝穿模 */
  private resolveCollisions(dt: number) {
    const all: Racer[] = [this.player, ...this.rivals.filter((r) => !r.out && !r.finished)];
    const P = this.path;
    const minS = CAR_LEN * 1.06;
    const minL = CAR_WID * 1.04;
    const WALL = this.def.theme.roadWidth / 2 + 7.6;
    // 迭代松弛：一次分离可能把车推进另一台车，需多轮收敛
    for (let iter = 0; iter < 16; iter++) {
      let moved = false;
      for (let i = 0; i < all.length; i++) {
        for (let j = i + 1; j < all.length; j++) {
          const a = all[i]; const b = all[j];
          const ds = P.delta(a.s, b.s);
          if (Math.abs(ds) >= minS) continue;
          const dl = a.lat - b.lat;
          if (Math.abs(dl) >= minL) continue;
          moved = true;
          const overS = minS - Math.abs(ds);
          const overL = minL - Math.abs(dl);
          if (overL / minL <= overS / minS) {
            const dir = dl === 0 ? (a.id > b.id ? 1 : -1) : Math.sign(dl);
            const push = overL / 2 + 0.004;
            const aWant = a.lat + dir * push;
            const bWant = b.lat - dir * push;
            const aGot = clamp(aWant, -WALL, WALL);
            const bGot = clamp(bWant, -WALL, WALL);
            // 一侧被护栏夹住 → 把缺失的位移补给另一侧
            a.lat = clamp(aGot - (bWant - bGot), -WALL, WALL);
            b.lat = clamp(bGot - (aWant - aGot), -WALL, WALL);
          } else {
            const dir = ds === 0 ? (a.id > b.id ? 1 : -1) : Math.sign(ds);
            const push = overS / 2 + 0.004;
            a.s += dir * push; a.dist += dir * push;
            b.s -= dir * push; b.dist -= dir * push;
          }
        }
      }
      if (!moved) break;
    }
    // 冲量与伤害（收敛后统一结算一次）
    for (let i = 0; i < all.length; i++) {
      for (let j = i + 1; j < all.length; j++) {
        const a = all[i]; const b = all[j];
        const ds = P.delta(a.s, b.s);
        const dl = a.lat - b.lat;
        // 接触判定略放宽，用于结算冲量
        if (Math.abs(ds) >= minS * 1.12 || Math.abs(dl) >= minL * 1.12) continue;
        const front = ds > 0 ? a : b;
        const back = ds > 0 ? b : a;
        const rel = back.speed - front.speed;
        if (rel > 0) { back.speed -= rel * 0.5; front.speed += rel * 0.2; }
        if (a.id === -1 || b.id === -1) {
          const other = a.id === -1 ? b : a;
          if (this.ghostItemT <= 0 && this.invuln <= 0 && Math.abs(this.player.speed - other.speed) > 8) {
            this.damage(DMG_CAR * dt * 6, "车辆碰撞");
          }
          this.shake = Math.max(this.shake, 0.18);
        }
      }
    }
    // 位置修正后重新摆放
    for (const r of all) this.placeCar(r, r.id === -1 ? this.airY : 0);
  }

  private animateRig(r: Racer, dt: number, braking: boolean) {
    const spin = r.speed * dt / (r.skin.model.wheelR || 0.36);
    for (const w of r.rig.wheels) w.rotation.x -= spin;
    const st = r.id === -1 ? ((this.keys.left ? -1 : 0) + (this.keys.right ? 1 : 0)) : 0;
    for (const w of r.rig.frontWheels) w.rotation.y = lerp(w.rotation.y, st * 0.42 + r.yaw * 0.5, dt * 12);
    const boosting = r.id === -1 ? this.boost > 0 : r.boost > 0;
    const hot = this.boostTone === "perfect" || this.boostTone === "wc" || this.boostTone === "link";
    for (const fl of r.rig.flames) {
      fl.visible = boosting;
      if (boosting) {
        const k = 0.75 + Math.random() * 0.6;
        fl.scale.set(k, 0.8 + Math.random() * 0.7, k);
        (fl.material as THREE.MeshBasicMaterial).color.set(r.id === -1 && hot ? "#ffd166" : "#8fd8ff");
      }
    }
    r.rig.brakeMat.emissiveIntensity = braking ? 4.2 : 1.1;
    if (r.rig.underglow) r.rig.underglow.intensity = boosting ? 5 : 2.2;
    if (r.id === -1 && this.invuln > 0) r.rig.group.visible = Math.floor(this.invuln * 12) % 2 === 0;
    else r.rig.group.visible = true;
  }

  // ================================================================ 喷射
  private applyBoost(t0: number, mult: number, label: string, tone: string, extend = false) {
    const t = t0 * this.tuning.nitro;
    this.boost = extend ? this.boost + t : Math.max(this.boost, t);
    this.boostMult = Math.max(this.boostMult, mult);
    this.boostTone = tone;
    if (tone === "mini") this.counters.mini++;
    else if (tone === "double") this.counters.double++;
    else if (tone === "perfect") this.counters.perfect++;
    else if (tone === "wc") this.counters.wc++;
    else if (tone === "link") this.counters.link++;
    this.combo++;
    this.bestCombo = Math.max(this.bestCombo, this.combo);
    this.comboTimer = COMBO_TTL;
    this.boostLabel = this.combo > 1 ? `${label} x${this.combo}` : label;
    this.boostLabelT = 0.9;
    this.boostSeq++;
    this.shake = Math.max(this.shake, tone === "perfect" || tone === "wc" ? 0.5 : 0.25);
  }

  private endDrift(award: boolean) {
    if (!this.drifting) return;
    this.drifting = false;
    const dt = this.driftTime;
    this.driftTime = 0;
    if (!award || dt < 0.45) { this.wcArmed = false; return; }
    if (this.wcArmed) {
      this.wcArmed = false;
      this.applyBoost(0.85, WC_MULT, "WC喷!!", "wc", true);
      this.onPerfect?.();
      return;
    }
    this.applyBoost(dt >= 1.2 ? MINI_T * 1.15 : MINI_T, 1.22, "小喷!", "mini");
    this.onMiniBoost?.();
    this.dblWindow = DBL_WINDOW;
  }

  private tryDouble() {
    const el = 1 - this.dblWindow / DBL_WINDOW;
    this.dblWindow = 0;
    if (el >= DBL_PERFECT[0] && el <= DBL_PERFECT[1]) {
      this.applyBoost(1.3, 1.38, "完美双喷!!", "perfect");
      this.onPerfect?.();
    } else {
      this.applyBoost(0.95, 1.3, "双喷!", "double");
      this.onMiniBoost?.();
    }
  }

  useNitro() {
    if (this.phase !== "racing" || this.paused || this.cans <= 0) return false;
    if (this.boost > LINK_WINDOW) return false;
    this.cans--;
    if (this.boost > 0) {
      const perfect = this.boost <= 0.25;
      this.applyBoost(NOS_T * (perfect ? 1 : 0.85), perfect ? WC_MULT : BOOST_MULT, perfect ? "完美LINK!!" : "LINK喷!", "link", true);
      if (perfect) this.onPerfect?.(); else this.onNos?.();
      return true;
    }
    if (this.drifting) {
      this.wcArmed = true;
      this.applyBoost(NOS_T, BOOST_MULT, "WC装填…", "nos");
      this.onNos?.();
      return true;
    }
    this.applyBoost(NOS_T, BOOST_MULT, "氮气加速!", "nos");
    this.onNos?.();
    return true;
  }

  // ================================================================ 道具
  get item() { return this.itemSlot; }
  private flashItem(t: string) { this.itemFlash = t; this.itemFlashT = 1.5; }

  useItem() {
    if (this.phase !== "racing" || this.paused || !this.itemSlot) return false;
    const id = this.itemSlot;
    this.itemSlot = null;
    this.itemsUsed++;
    const p = this.player;
    switch (id) {
      case "banana": case "mine": {
        const mesh = new THREE.Mesh(
          id === "banana" ? new THREE.TorusGeometry(0.5, 0.2, 8, 14) : new THREE.SphereGeometry(0.5, 10, 8),
          new THREE.MeshStandardMaterial({ color: id === "banana" ? "#facc15" : "#f97316", emissive: id === "banana" ? "#a16207" : "#7c2d12", emissiveIntensity: 0.7, metalness: 0.4, roughness: 0.4 }),
        );
        this.fxGroup.add(mesh);
        this.dropped.push({ kind: id, s: p.s - 7, lat: p.lat, owner: -1, life: 30, armed: 1, mesh });
        this.flashItem(`${ITEMS[id].emoji} 已布置`);
        break;
      }
      case "shield": this.shieldT = 8; this.flashItem("🛡️ 护盾开启"); break;
      case "ghost": this.ghostItemT = 5; this.flashItem("👻 幽灵穿透"); break;
      case "magnet": this.magnetT = 3; this.flashItem("🧲 磁力牵引"); break;
      case "warp": p.s += 90; p.dist += 90; this.shake = 0.7; this.flashItem("🌀 时空跳跃"); break;
      case "lightning": {
        let n = 0;
        for (const r of this.rivals) {
          if (r.out || r.finished) continue;
          if (r.shield > 0) { r.shield = 0; continue; }
          r.speed *= 0.45; r.stun = 1.6; n++;
        }
        this.flashItem(`⚡ 电击 ${n} 名对手`);
        this.shake = 0.8;
        break;
      }
      case "water":
        for (const r of this.rivals) if (r.dist > p.dist) r.stun = Math.max(r.stun, 1.2);
        this.flashItem("💧 水弹泼洒");
        break;
      case "missile": {
        let tgt: Racer | null = null; let best = Infinity;
        for (const r of this.rivals) {
          if (r.out || r.finished) continue;
          const gap = r.dist - p.dist;
          if (gap > 0 && gap < best) { best = gap; tgt = r; }
        }
        const mesh = new THREE.Mesh(
          new THREE.ConeGeometry(0.28, 1.3, 8),
          new THREE.MeshStandardMaterial({ color: "#ef4444", emissive: "#ff6b3d", emissiveIntensity: 2 }),
        );
        this.fxGroup.add(mesh);
        this.missiles.push({ s: p.s, lat: p.lat, target: tgt ? tgt.id : -2, owner: -1, life: 6, mesh });
        this.flashItem(tgt ? `🚀 锁定 ${tgt.name}` : "🚀 导弹发射");
        break;
      }
    }
    this.onItemUse?.(id);
    return true;
  }

  private hitPlayer(power: number, spin: boolean, msg: string) {
    if (this.ghostItemT > 0) return;
    if (this.shieldT > 0) { this.shieldT = 0; this.flashItem("🛡️ 护盾抵挡！"); this.onShield?.(); return; }
    this.player.speed *= power;
    this.boost = 0; this.boostMult = 1;
    this.endDrift(false);
    if (spin) this.spinT = 1.1;
    this.damage(14, msg);
  }

  private updateItems(dt: number) {
    this.shieldT = Math.max(0, this.shieldT - dt);
    this.ghostItemT = Math.max(0, this.ghostItemT - dt);
    if (this.itemFlashT > 0) this.itemFlashT -= dt;
    if (!this.itemsEnabled) return;
    const P = this.path;
    const p = this.player;

    if (this.itemRoll > 0) {
      this.itemRoll -= dt;
      if (this.itemRoll <= 0) {
        this.itemSlot = drawItem(this.getPosition(), RIVALS + 1, this.rng);
        this.onItemGet?.(this.itemSlot);
      }
    }

    for (const box of this.itemBoxes) {
      if (box.respawn > 0) {
        box.respawn -= dt;
        if (box.respawn <= 0) box.mesh.visible = true;
        continue;
      }
      if (Math.abs(P.delta(p.s, box.s)) < 3 && Math.abs(box.lat - p.lat) < 2) {
        box.respawn = 6; box.mesh.visible = false;
        if (!this.itemSlot && this.itemRoll <= 0) this.itemRoll = 0.7;
        continue;
      }
      for (const r of this.rivals) {
        if (r.out || r.finished || r.item) continue;
        if (Math.abs(P.delta(r.s, box.s)) < 3 && Math.abs(box.lat - r.lat) < 2) {
          box.respawn = 6; box.mesh.visible = false;
          r.item = drawItem(this.rivalPos(r), RIVALS + 1, this.rng);
          r.itemCd = 1 + this.rng() * 3;
          break;
        }
      }
    }

    for (let i = this.dropped.length - 1; i >= 0; i--) {
      const d = this.dropped[i];
      d.life -= dt;
      if (d.armed > 0) d.armed -= dt;
      const f = P.frameAt(d.s, this.tmpFrame);
      d.mesh.position.copy(f.pos).addScaledVector(f.bin, d.lat).addScaledVector(f.nor, 0.4);
      d.mesh.rotation.y += dt * 2;
      if (d.life <= 0) { this.fxGroup.remove(d.mesh); this.dropped.splice(i, 1); continue; }
      if (Math.abs(P.delta(p.s, d.s)) < 2.6 && Math.abs(d.lat - p.lat) < 1.7 && !(d.owner === -1 && d.armed > 0)) {
        this.fxGroup.remove(d.mesh); this.dropped.splice(i, 1);
        this.hitPlayer(d.kind === "mine" ? 0.34 : 0.58, d.kind === "banana", d.kind === "mine" ? "💣 地雷" : "🍌 打滑");
        continue;
      }
      for (const r of this.rivals) {
        if (r.out || r.finished) continue;
        if (Math.abs(P.delta(r.s, d.s)) < 2.6 && Math.abs(d.lat - r.lat) < 1.7 && !(d.owner === r.id && d.armed > 0)) {
          if (r.shield > 0) { r.shield = 0; } else { r.speed *= d.kind === "mine" ? 0.35 : 0.6; r.stun = 1; }
          this.fxGroup.remove(d.mesh); this.dropped.splice(i, 1);
          break;
        }
      }
    }

    for (let i = this.missiles.length - 1; i >= 0; i--) {
      const m = this.missiles[i];
      m.life -= dt;
      m.s += MAX_SPEED * 1.6 * dt;
      const tgt = m.target === -1 ? p : this.rivals.find((r) => r.id === m.target);
      if (tgt) m.lat += (tgt.lat - m.lat) * Math.min(1, dt * 4);
      const f = P.frameAt(m.s, this.tmpFrame);
      m.mesh.position.copy(f.pos).addScaledVector(f.bin, m.lat).addScaledVector(f.nor, 1);
      m.mesh.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(f.bin, f.nor, f.tan.clone().negate()));
      m.mesh.rotateX(Math.PI / 2);
      if (m.life <= 0) { this.fxGroup.remove(m.mesh); this.missiles.splice(i, 1); continue; }
      if (tgt && Math.abs(P.delta(m.s, tgt.s)) < 4) {
        this.fxGroup.remove(m.mesh); this.missiles.splice(i, 1);
        if (tgt === p) this.hitPlayer(0.4, true, "🚀 被导弹命中");
        else {
          const r = tgt as Racer;
          if (r.shield > 0) r.shield = 0;
          else { r.speed *= 0.35; r.stun = 1.4; }
          this.flashItem(`🚀 命中 ${r.name}！`);
        }
        this.onExplode?.();
      }
    }

    for (const r of this.rivals) {
      if (r.out || r.finished || !r.item) continue;
      r.itemCd -= dt;
      if (r.itemCd > 0) continue;
      const id = r.item; r.item = null;
      if (id === "banana" || id === "mine") {
        const mesh = new THREE.Mesh(
          id === "banana" ? new THREE.TorusGeometry(0.5, 0.2, 8, 14) : new THREE.SphereGeometry(0.5, 10, 8),
          new THREE.MeshStandardMaterial({ color: id === "banana" ? "#facc15" : "#f97316", emissive: "#7c2d12", emissiveIntensity: 0.6 }),
        );
        this.fxGroup.add(mesh);
        this.dropped.push({ kind: id, s: r.s - 6, lat: r.lat, owner: r.id, life: 26, armed: 1, mesh });
      } else if (id === "missile" && r.dist < p.dist) {
        const mesh = new THREE.Mesh(new THREE.ConeGeometry(0.28, 1.3, 8), new THREE.MeshStandardMaterial({ color: "#ef4444", emissive: "#ff6b3d", emissiveIntensity: 2 }));
        this.fxGroup.add(mesh);
        this.missiles.push({ s: r.s, lat: r.lat, target: -1, owner: r.id, life: 6, mesh });
      } else if (id === "lightning" && r.dist < p.dist) {
        this.hitPlayer(0.55, true, "⚡ 被闪电击中");
      } else if (id === "shield") r.shield = 8;
      else r.boost = Math.max(r.boost, 1.1);
    }
  }

  private rivalPos(rv: Racer) {
    let pos = 1;
    if (this.player.dist > rv.dist) pos++;
    for (const o of this.rivals) if (o !== rv && !o.out && o.dist > rv.dist) pos++;
    return pos;
  }

  // ================================================================ 淘汰 / 幽灵 / 驾照
  private updateElim(dt: number) {
    if (this.mode !== "elim" || this.eliminated) return;
    this.elimTimer -= dt;
    this.elimWarn = this.elimTimer <= 4;
    if (this.elimTimer > 0) return;
    this.elimTimer = ELIM_INTERVAL;
    const st = this.getStandings();
    if (st.length <= 1) return;
    const last = st[st.length - 1];
    if (last.isPlayer) {
      this.eliminated = true;
      this.onEliminate?.(this.playerName);
      this.finish();
      return;
    }
    const victim = this.rivals.find((r) => !r.out && !r.finished && r.name === last.name);
    if (victim) {
      victim.out = true;
      victim.rig.group.visible = false;
      this.elimCount++;
      this.onEliminate?.(victim.name);
      this.flashItem(`💥 ${victim.name} 被淘汰`);
    }
    if (this.rivals.every((r) => r.out || r.finished)) this.finish();
  }

  private updateGhost(dt: number) {
    if (!this.ghostRig || !this.ghostData || this.ghostData.length < 2) return;
    this.ghostT2 += dt;
    const d = this.ghostData;
    const t = this.ghostT2;
    let lo = 0; let hi = d.length - 1;
    if (t >= d[hi].t) lo = hi - 1;
    else {
      while (lo < hi - 1) { const mid = (lo + hi) >> 1; if (d[mid].t <= t) lo = mid; else hi = mid; }
    }
    const a = d[lo]; const b = d[Math.min(d.length - 1, lo + 1)];
    const f = clamp((t - a.t) / Math.max(1e-4, b.t - a.t), 0, 1);
    const s = lerp(a.z, b.z, f);
    const lat = lerp(a.x, b.x, f);
    const fr = this.path.frameAt(s, this.tmpFrame);
    this.ghostRig.group.position.copy(fr.pos).addScaledVector(fr.bin, lat).addScaledVector(fr.nor, 0);
    this.ghostRig.group.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(
      new THREE.Vector3().crossVectors(fr.nor, fr.tan).normalize().negate(), fr.nor, fr.tan.clone().negate(),
    ));
  }

  private checkLicense() {
    const g = this.licenseGoal;
    if (!g || this.licensePassed) return;
    const c = this.counters;
    const val = g.type === "drift" ? c.drift : g.type === "mini" ? c.mini : g.type === "double" ? c.double
      : g.type === "perfect" ? c.perfect : g.type === "wc" ? c.wc : g.type === "link" ? c.link
      : g.type === "combo" ? this.bestCombo : g.type === "clean" ? c.cleanTime : 0;
    const need = g.count ?? g.seconds ?? 1;
    this.licenseProgress = clamp(val / need, 0, 1);
    if (val >= need) { this.licensePassed = true; this.finish(); }
  }

  private finish() {
    this.phase = "finished";
    this.finishTime = this.totalTime;
    this.finalStandings = this.getStandings();
    this.onFinish?.();
  }

  // ================================================================ 相机
  private menuCam(dt: number) {
    this.totalTime += dt;
    const s = (this.totalTime * 14) % this.path.length;
    const f = this.path.frameAt(s, this.tmpFrame);
    const orbit = this.totalTime * 0.25;
    this.camPos.copy(f.pos)
      .addScaledVector(f.bin, Math.cos(orbit) * 16)
      .addScaledVector(f.tan, Math.sin(orbit) * 16)
      .addScaledVector(f.nor, 7);
    this.camera.position.lerp(this.camPos, 0.06);
    this.camera.lookAt(f.pos.clone().addScaledVector(f.nor, 2));
    this.camera.fov = 62;
    this.camera.updateProjectionMatrix();
    // 菜单里让玩家车停在起跑线展示
    if (this.player) {
      this.player.s = this.path.length - 6;
      this.player.lat = 0;
      this.placeCar(this.player, 0);
      for (const w of this.player.rig.wheels) w.rotation.x -= dt * 2;
    }
    this.sunFollow(f.pos);
  }

  /** 入场动画：从高空俯冲到车尾 */
  private introCam() {
    const p = this.player;
    const f = this.path.frameAt(p.s, this.tmpFrame);
    const T = 1 - clamp(this.introT / 3.6, 0, 1); // 0 → 1
    const ease = T < 0.5 ? 2 * T * T : 1 - Math.pow(-2 * T + 2, 2) / 2;
    // 起点：车头前方高空环绕；终点：车尾常规机位
    const orbit = (1 - ease) * Math.PI * 1.5;
    const dist = lerp(26, 8.5, ease);
    const height = lerp(16, 3.4, ease);
    const carPos = f.pos.clone().addScaledVector(f.bin, p.lat);
    this.camera.position.copy(carPos)
      .addScaledVector(f.tan, -Math.cos(orbit) * dist)
      .addScaledVector(f.bin, Math.sin(orbit) * dist)
      .addScaledVector(f.nor, height);
    this.camera.lookAt(carPos.clone().addScaledVector(f.nor, 1.2));
    this.camera.fov = lerp(52, 70, ease);
    this.camera.updateProjectionMatrix();
    this.sunFollow(carPos);
    for (const w of p.rig.wheels) w.rotation.x -= 0.02;
  }

  private chaseCam(dt: number, still: boolean) {
    const p = this.player;
    const f = this.path.frameAt(p.s, this.tmpFrame);
    const carPos = f.pos.clone().addScaledVector(f.bin, p.lat).addScaledVector(f.nor, this.airY);
    const spd = p.speed / MAX_SPEED;
    const back = still ? 8.2 : lerp(8.4, 10.6, spd);
    const up = still ? 3.3 : lerp(3.3, 4.1, spd) + this.airY * 0.25;
    const side = p.lat * 0.16 + (this.drifting ? this.driftDir * 1.5 : 0);

    this.camPos.copy(carPos).addScaledVector(f.tan, -back).addScaledVector(f.nor, up).addScaledVector(f.bin, side);
    const k = 1 - Math.pow(0.0016, dt);
    this.camera.position.lerp(this.camPos, k);

    this.camLook.copy(carPos).addScaledVector(f.tan, 9).addScaledVector(f.nor, 1.5);
    const lookTarget = this.camLook.clone();
    // 震屏
    if (this.shake > 0) {
      this.camShake.set((Math.random() - 0.5), (Math.random() - 0.5), (Math.random() - 0.5)).multiplyScalar(this.shake * 0.55);
      this.camera.position.add(this.camShake);
    }
    this.camera.lookAt(lookTarget);
    // 漂移/氮气时轻微侧倾
    const roll = -p.yaw * 0.22 + f.bank * 0.5;
    this.camera.rotateZ(roll);
    const targetFov = 68 + spd * 8 + (this.boost > 0 ? 12 : 0);
    this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, dt * 5);
    this.camera.updateProjectionMatrix();
    this.sunFollow(carPos);
  }

  private sunFollow(target: THREE.Vector3) {
    this.sun.position.set(target.x + 60, target.y + 90, target.z + 40);
    this.sun.target.position.copy(target);
    this.sun.target.updateMatrixWorld();
  }

  private animateFx(dt: number) {
    for (const b of this.itemBoxes) {
      const spin = b.mesh.userData.spin as THREE.Mesh | undefined;
      if (spin) { spin.rotation.y += dt * 2.2; spin.rotation.x += dt * 1.1; }
      b.mesh.children[1] && (b.mesh.children[1].rotation.z += dt * 1.6);
    }
  }

  // ================================================================ 输出
  getPosition() {
    if (this.mode === "time" || this.mode === "license") return 1;
    let pos = 1;
    for (const r of this.rivals) if (!r.out && r.dist > this.player.dist) pos++;
    return pos;
  }

  getStandings(): Standing[] {
    if (this.mode === "time" || this.mode === "license") return [];
    const list: Standing[] = [
      { name: this.playerName, lap: Math.min(this.lap, this.totalLaps), isPlayer: true, isTeammate: true, prog: this.player.dist, color: this.playerSkin.paintA, finished: this.phase === "finished" },
      ...this.rivals.filter((r) => !r.out).map((r) => ({
        name: r.name, lap: Math.min(Math.floor(r.dist / this.path.length) + 1, this.totalLaps),
        isPlayer: false, isTeammate: r.isTeammate, prog: r.dist, color: r.skin.paintA, finished: r.finished,
      })),
    ];
    list.sort((a, b) => b.prog - a.prog);
    return list;
  }

  private teamScore(mine: boolean) {
    if (this.mode !== "team") return 0;
    const st = this.finalStandings.length ? this.finalStandings : this.getStandings();
    let sc = 0;
    st.forEach((s, i) => { if (s.isTeammate === mine) sc += Math.max(0, st.length - i); });
    return sc;
  }

  getHud(): Hud3D {
    return {
      phase: this.phase,
      speedKmh: Math.round(this.player.speed * 3.6),
      speedPct: clamp(this.player.speed / MAX_SPEED, 0, 1.4),
      lap: Math.min(this.lap, this.totalLaps), totalLaps: this.totalLaps,
      lapTime: this.lapTime, lastLap: this.lastLap, bestLap: this.bestLap, totalTime: this.totalTime,
      hp: Math.max(0, this.hp), maxHp: MAX_HP, hpFlash: this.hpFlash,
      countdown: this.countdown, goTimer: this.goTimer, introT: this.introT,
      drifting: this.drifting, driftTime: this.driftTime, charge: this.charge, cans: this.cans, boost: this.boost,
      boostLabel: this.boostLabelT > 0 ? this.boostLabel : "", boostSeq: this.boostSeq, combo: this.combo,
      dblWindow: this.dblWindow, dblPerfect: DBL_PERFECT, wcArmed: this.wcArmed,
      linkReady: this.boost > 0 && this.boost <= LINK_WINDOW && this.cans > 0,
      airborne: this.airborne, offroad: Math.abs(this.player.lat) > this.def.theme.roadWidth / 2, paused: this.paused,
      mode: this.mode, position: this.getPosition(),
      totalRacers: this.mode === "time" || this.mode === "license" ? 1 : RIVALS + 1,
      standings: this.getStandings(), teamScore: this.teamScore(true), rivalScore: this.teamScore(false),
      itemsEnabled: this.itemsEnabled, item: this.itemSlot, itemRolling: this.itemRoll > 0,
      itemFlash: this.itemFlashT > 0 ? this.itemFlash : "",
      shieldT: this.shieldT, ghostT: this.ghostItemT,
      elimTimer: this.mode === "elim" ? Math.max(0, this.elimTimer) : 0,
      elimWarn: this.elimWarn, elimCount: this.elimCount, eliminated: this.eliminated,
      licenseProgress: this.licenseProgress, trackId: this.trackId,
      mapPlayer: this.mapOf(this.player.s),
      mapRivals: this.rivals.filter((r) => !r.out).map((r) => ({ ...this.mapOf(r.s), teammate: r.isTeammate })),
      mapPath: this.mapPathPts,
    };
  }

  getResults() {
    return {
      lapTimes: [...this.lapTimes], totalTime: this.finishTime || this.totalTime,
      bestLapTime: this.bestLap, maxSpeedKmh: Math.round(this.maxSpeedSeen * 3.6),
      bestCombo: this.bestCombo, perfectCount: this.counters.perfect,
      position: this.getPosition(), totalRacers: this.mode === "time" || this.mode === "license" ? 1 : RIVALS + 1,
      standings: this.finalStandings.length ? this.finalStandings : this.getStandings(),
      mode: this.mode, teamScore: this.teamScore(true), rivalScore: this.teamScore(false),
      eliminated: this.eliminated, elimCount: this.elimCount, licensePassed: this.licensePassed,
      itemsUsed: this.itemsUsed, crashes: this.counters.crashes, distance: this.player.dist,
      counters: { ...this.counters }, overtakes: 0, hp: Math.round(this.hp),
    };
  }

  getGhostRecording() { return this.ghostRec; }

  render() { this.renderer?.render(this.scene, this.camera); }
}
