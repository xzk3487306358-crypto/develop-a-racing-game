import * as THREE from "three";

// ---------------------------------------------------------------------------
// 3D 车辆建模：程序化生成高质感车体（金属漆 / 玻璃 / 霓虹 / 尾焰 / 轮毂）
// ---------------------------------------------------------------------------

export type WingKind = "none" | "lip" | "gt" | "dual" | "swan";
export type BodyKind = "gt" | "hyper" | "muscle" | "kart" | "concept" | "mech";

export interface CarModel3D {
  id: string;
  name: string;
  tier: "B" | "A" | "S" | "T";
  desc: string;
  body: BodyKind;
  len: number;
  wid: number;
  hei: number;
  cabin: number;
  wing: WingKind;
  wheelR: number;
  glow: boolean;
  stats: { speed: number; accel: number; grip: number };
}

export const CAR_MODELS: CarModel3D[] = [
  { id: "gt", name: "疾风 GT", tier: "B", desc: "均衡型入门跑车，操控稳定", body: "gt", len: 4.3, wid: 1.9, hei: 1.15, cabin: 0.62, wing: "lip", wheelR: 0.36, glow: false, stats: { speed: 3, accel: 4, grip: 4 } },
  { id: "muscle", name: "暴烈者", tier: "B", desc: "宽体肌肉车，起步爆发力强", body: "muscle", len: 4.6, wid: 2.1, hei: 1.25, cabin: 0.5, wing: "gt", wheelR: 0.4, glow: false, stats: { speed: 3, accel: 5, grip: 3 } },
  { id: "kart", name: "闪电小蜂", tier: "A", desc: "轻量卡丁，贴地漂移灵活", body: "kart", len: 3.5, wid: 1.8, hei: 0.85, cabin: 0.55, wing: "none", wheelR: 0.32, glow: false, stats: { speed: 3, accel: 4, grip: 5 } },
  { id: "hyper", name: "苍穹 X", tier: "S", desc: "极速超跑，双层尾翼下压", body: "hyper", len: 4.7, wid: 2.0, hei: 1.05, cabin: 0.72, wing: "dual", wheelR: 0.38, glow: true, stats: { speed: 5, accel: 4, grip: 3 } },
  { id: "concept", name: "曙光概念", tier: "S", desc: "全罩座舱，抓地力顶级", body: "concept", len: 4.5, wid: 2.0, hei: 1.0, cabin: 0.95, wing: "swan", wheelR: 0.36, glow: true, stats: { speed: 4, accel: 3, grip: 5 } },
  { id: "mech", name: "引擎之心", tier: "T", desc: "机甲核心，全属性顶配", body: "mech", len: 4.8, wid: 2.15, hei: 1.1, cabin: 0.8, wing: "swan", wheelR: 0.42, glow: true, stats: { speed: 5, accel: 5, grip: 4 } },
];

export type LiveryId = "solid" | "stripe" | "flame" | "carbon" | "split" | "neon" | "camo" | "rally" | "galaxy" | "circuit";

export const LIVERIES: { id: LiveryId; name: string }[] = [
  { id: "solid", name: "纯色" },
  { id: "stripe", name: "赛道条纹" },
  { id: "flame", name: "烈焰" },
  { id: "carbon", name: "碳纤维" },
  { id: "split", name: "撞色分割" },
  { id: "neon", name: "霓虹脉冲" },
  { id: "camo", name: "迷彩" },
  { id: "rally", name: "拉力涂装" },
  { id: "galaxy", name: "星河" },
  { id: "circuit", name: "电路" },
];

export const PAINTS = [
  { name: "烈焰红", a: "#ff2e63", b: "#ffb03a" },
  { name: "深海蓝", a: "#2f9bff", b: "#7ce8ff" },
  { name: "魅影紫", a: "#8b5cf6", b: "#f472b6" },
  { name: "翡翠绿", a: "#10b981", b: "#a3e635" },
  { name: "熔金黄", a: "#ffb020", b: "#fff06a" },
  { name: "曜石黑", a: "#23262f", b: "#7c8797" },
  { name: "冰川白", a: "#eef3f8", b: "#9ec5e8" },
  { name: "机甲橙", a: "#ff6b18", b: "#ffd166" },
  { name: "樱绯粉", a: "#ff5fa2", b: "#ffd1e6" },
  { name: "钛银灰", a: "#9aa3b2", b: "#dfe6ef" },
];

export interface CarSkin3D {
  model: CarModel3D;
  paintA: string;
  paintB: string;
  livery: LiveryId;
}

export const defaultSkin3D = (): CarSkin3D => ({ model: CAR_MODELS[0], paintA: PAINTS[0].a, paintB: PAINTS[0].b, livery: "stripe" });

// ---------------------------------------------------------------- 涂装贴图
const texCache = new Map<string, THREE.CanvasTexture>();

export function liveryTexture(livery: LiveryId, a: string, b: string): THREE.CanvasTexture | null {
  if (typeof document === "undefined") return null;
  const key = `${livery}|${a}|${b}`;
  const hit = texCache.get(key);
  if (hit) return hit;

  const S = 256;
  const cv = document.createElement("canvas");
  cv.width = S;
  cv.height = S;
  const c = cv.getContext("2d")!;
  c.fillStyle = a;
  c.fillRect(0, 0, S, S);

  const shade = (hex: string, amt: number) => {
    const n = parseInt(hex.slice(1), 16);
    const f = (x: number) => Math.max(0, Math.min(255, Math.round(amt < 0 ? x * (1 + amt) : x + (255 - x) * amt)));
    return `rgb(${f((n >> 16) & 255)},${f((n >> 8) & 255)},${f(n & 255)})`;
  };

  switch (livery) {
    case "stripe":
      c.fillStyle = b;
      c.fillRect(S * 0.4, 0, S * 0.08, S);
      c.fillRect(S * 0.52, 0, S * 0.08, S);
      break;
    case "flame":
      c.fillStyle = b;
      for (let i = 0; i < 5; i++) {
        c.beginPath();
        c.moveTo(0, S * (0.15 * i));
        c.quadraticCurveTo(S * 0.4, S * (0.1 * i + 0.05), S * 0.75, S * (0.14 * i + 0.02));
        c.quadraticCurveTo(S * 0.45, S * (0.12 * i + 0.12), 0, S * (0.15 * i + 0.12));
        c.fill();
      }
      break;
    case "carbon": {
      const st = 8;
      for (let y = 0; y < S; y += st)
        for (let x = 0; x < S; x += st) {
          c.fillStyle = ((x / st + y / st) | 0) % 2 ? "#15171d" : "#272b36";
          c.fillRect(x, y, st, st);
        }
      c.fillStyle = b;
      c.fillRect(0, S * 0.46, S, S * 0.06);
      break;
    }
    case "split":
      c.fillStyle = b;
      c.beginPath();
      c.moveTo(0, S);
      c.lineTo(S, S * 0.25);
      c.lineTo(S, S);
      c.fill();
      break;
    case "neon":
      c.strokeStyle = b;
      c.lineWidth = 7;
      c.shadowColor = b;
      c.shadowBlur = 18;
      for (let i = 0; i < 4; i++) {
        c.beginPath();
        c.moveTo(0, S * (0.2 + i * 0.2));
        c.lineTo(S, S * (0.13 + i * 0.2));
        c.stroke();
      }
      c.shadowBlur = 0;
      break;
    case "camo":
      for (let i = 0; i < 26; i++) {
        c.fillStyle = i % 3 === 0 ? b : i % 3 === 1 ? shade(a, -0.4) : shade(a, 0.22);
        c.beginPath();
        c.ellipse(((i * 71) % S), ((i * 113) % S), 26, 17, i, 0, Math.PI * 2);
        c.fill();
      }
      break;
    case "rally":
      c.fillStyle = b;
      c.fillRect(0, S * 0.35, S, S * 0.12);
      c.fillStyle = "#f8fafc";
      c.beginPath();
      c.arc(S * 0.5, S * 0.66, S * 0.16, 0, Math.PI * 2);
      c.fill();
      c.fillStyle = shade(a, -0.55);
      c.font = "900 58px system-ui";
      c.textAlign = "center";
      c.textBaseline = "middle";
      c.fillText("07", S * 0.5, S * 0.67);
      break;
    case "galaxy": {
      const g = c.createLinearGradient(0, 0, S, S);
      g.addColorStop(0, shade(a, -0.5));
      g.addColorStop(0.5, a);
      g.addColorStop(1, b);
      c.fillStyle = g;
      c.fillRect(0, 0, S, S);
      for (let i = 0; i < 160; i++) {
        c.fillStyle = `rgba(255,255,255,${0.25 + Math.random() * 0.7})`;
        c.fillRect(Math.random() * S, Math.random() * S, Math.random() * 2.2, Math.random() * 2.2);
      }
      break;
    }
    case "circuit":
      c.strokeStyle = b;
      c.lineWidth = 3;
      for (let i = 0; i < 26; i++) {
        const x = (i * 37) % S;
        const y = (i * 61) % S;
        c.beginPath();
        c.moveTo(x, y);
        c.lineTo(x + 40, y);
        c.lineTo(x + 40, y + 34);
        c.lineTo(x + 88, y + 34);
        c.stroke();
        c.fillStyle = b;
        c.beginPath();
        c.arc(x + 40, y + 34, 4.5, 0, Math.PI * 2);
        c.fill();
      }
      break;
    default:
      break;
  }

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  texCache.set(key, tex);
  return tex;
}

// ---------------------------------------------------------------- 车体几何
/** 用锥形箱体做出车身收腰效果 */
function taperBox(len: number, wid: number, hei: number, frontScale: number, rearScale: number, topScale: number) {
  const g = new THREE.BoxGeometry(wid, hei, len, 2, 2, 4);
  const pos = g.attributes.position;
  const v = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);
    const tz = (v.z / (len / 2) + 1) / 2; // 0 尾 → 1 头
    const sideScale = THREE.MathUtils.lerp(rearScale, frontScale, tz);
    const ty = (v.y / (hei / 2) + 1) / 2; // 0 底 → 1 顶
    const vertScale = THREE.MathUtils.lerp(1, topScale, ty);
    v.x *= sideScale * vertScale;
    // 车头下压
    v.y -= Math.pow(Math.max(0, tz - 0.55) / 0.45, 2) * hei * 0.22;
    pos.setXYZ(i, v.x, v.y, v.z);
  }
  g.computeVertexNormals();
  return g;
}

function wheelMesh(r: number, width: number, rimColor: string) {
  const grp = new THREE.Group();
  const tyre = new THREE.Mesh(
    new THREE.CylinderGeometry(r, r, width, 22, 1),
    new THREE.MeshStandardMaterial({ color: "#111318", roughness: 0.85, metalness: 0.1 }),
  );
  tyre.rotation.z = Math.PI / 2;
  tyre.castShadow = true;
  grp.add(tyre);

  const rim = new THREE.Mesh(
    new THREE.CylinderGeometry(r * 0.62, r * 0.62, width * 1.04, 18, 1),
    new THREE.MeshStandardMaterial({ color: rimColor, roughness: 0.22, metalness: 1 }),
  );
  rim.rotation.z = Math.PI / 2;
  grp.add(rim);

  // 辐条
  for (let i = 0; i < 6; i++) {
    const spoke = new THREE.Mesh(
      new THREE.BoxGeometry(width * 1.06, r * 0.12, r * 1.12),
      new THREE.MeshStandardMaterial({ color: "#e8ecf3", roughness: 0.25, metalness: 0.95 }),
    );
    spoke.rotation.x = (i / 6) * Math.PI;
    grp.add(spoke);
  }
  // 刹车盘
  const disc = new THREE.Mesh(
    new THREE.CylinderGeometry(r * 0.46, r * 0.46, width * 1.12, 16),
    new THREE.MeshStandardMaterial({ color: "#3b3f4a", roughness: 0.5, metalness: 0.8, emissive: "#000000" }),
  );
  disc.rotation.z = Math.PI / 2;
  grp.add(disc);
  grp.userData.disc = disc;
  return grp;
}

export interface CarRig {
  group: THREE.Group;
  wheels: THREE.Group[];
  frontWheels: THREE.Group[];
  flames: THREE.Mesh[];
  brakeMat: THREE.MeshStandardMaterial;
  underglow: THREE.PointLight | null;
  bodyMat: THREE.MeshStandardMaterial;
  headMat: THREE.MeshStandardMaterial;
}

export function buildCar(skin: CarSkin3D, opts: { headlights?: boolean } = {}): CarRig {
  const m = skin.model;
  const g = new THREE.Group();
  const tex = liveryTexture(skin.livery, skin.paintA, skin.paintB);

  const bodyMat = new THREE.MeshStandardMaterial({
    ...(tex ? { map: tex } : { color: new THREE.Color(skin.paintA) }),
    roughness: m.tier === "T" ? 0.14 : 0.22,
    metalness: 0.92,
    envMapIntensity: 1.5,
  });
  const darkMat = new THREE.MeshStandardMaterial({ color: "#14161c", roughness: 0.55, metalness: 0.6 });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: "#0d1522", roughness: 0.06, metalness: 0.2,
    transmission: 0.55, thickness: 0.5, transparent: true, opacity: 0.82,
    envMapIntensity: 2,
  });

  // ---- 主车身
  const front = m.body === "muscle" ? 0.92 : m.body === "hyper" ? 0.78 : 0.85;
  const rear = m.body === "muscle" ? 1.0 : 0.94;
  const body = new THREE.Mesh(taperBox(m.len, m.wid, m.hei, front, rear, 0.86), bodyMat);
  body.position.y = m.hei * 0.5 + m.wheelR * 0.55;
  body.castShadow = true;
  body.receiveShadow = true;
  g.add(body);

  // ---- 侧裙 / 底盘
  const skirt = new THREE.Mesh(new THREE.BoxGeometry(m.wid * 1.02, m.hei * 0.2, m.len * 0.82), darkMat);
  skirt.position.y = m.wheelR * 0.55 + m.hei * 0.08;
  g.add(skirt);

  // ---- 座舱
  const cabLen = m.len * (0.3 + m.cabin * 0.2);
  const cabin = new THREE.Mesh(
    taperBox(cabLen, m.wid * 0.78, m.hei * 0.66, 0.7, 0.9, 0.62),
    glassMat,
  );
  cabin.position.set(0, m.hei * 1.02 + m.wheelR * 0.55, m.body === "muscle" ? -m.len * 0.02 : m.len * 0.02);
  g.add(cabin);

  // 座舱框
  const cabFrame = new THREE.Mesh(
    taperBox(cabLen * 1.03, m.wid * 0.8, m.hei * 0.68, 0.72, 0.92, 0.6),
    new THREE.MeshStandardMaterial({ color: skin.paintA, roughness: 0.3, metalness: 0.9, wireframe: false, transparent: true, opacity: 0.28 }),
  );
  cabFrame.position.copy(cabin.position);
  cabFrame.scale.setScalar(1.015);
  g.add(cabFrame);

  // ---- 车头进气 / 前唇
  const nose = new THREE.Mesh(new THREE.BoxGeometry(m.wid * 0.86, m.hei * 0.2, m.len * 0.1), darkMat);
  nose.position.set(0, m.wheelR * 0.6, m.len * 0.47);
  g.add(nose);

  // ---- 前大灯
  const headMat = new THREE.MeshStandardMaterial({
    color: "#dff1ff", emissive: opts.headlights === false ? "#223344" : "#bfe6ff",
    emissiveIntensity: 2.4, roughness: 0.2, metalness: 0.3,
  });
  for (const sx of [-1, 1]) {
    const hl = new THREE.Mesh(new THREE.BoxGeometry(m.wid * 0.26, m.hei * 0.11, m.len * 0.05), headMat);
    hl.position.set(sx * m.wid * 0.28, m.hei * 0.72 + m.wheelR * 0.3, m.len * 0.475);
    g.add(hl);
  }

  // ---- 尾灯（贯穿灯带）
  const brakeMat = new THREE.MeshStandardMaterial({ color: "#ff2233", emissive: "#8d1220", emissiveIntensity: 1.2, roughness: 0.3 });
  const tail = new THREE.Mesh(new THREE.BoxGeometry(m.wid * 0.84, m.hei * 0.1, m.len * 0.04), brakeMat);
  tail.position.set(0, m.hei * 0.82 + m.wheelR * 0.3, -m.len * 0.5);
  g.add(tail);

  // ---- 尾翼
  if (m.wing !== "none") {
    const wingW = m.wid * (m.wing === "dual" || m.wing === "swan" ? 1.06 : 0.9);
    const wingY = m.hei * (m.wing === "lip" ? 0.95 : 1.35) + m.wheelR * 0.55;
    const wingZ = -m.len * 0.46;
    const wingMat = new THREE.MeshStandardMaterial({ color: "#101218", roughness: 0.35, metalness: 0.85 });
    const blade = new THREE.Mesh(new THREE.BoxGeometry(wingW, m.hei * 0.07, m.len * 0.13), wingMat);
    blade.position.set(0, wingY, wingZ);
    blade.rotation.x = -0.16;
    blade.castShadow = true;
    g.add(blade);
    if (m.wing !== "lip") {
      for (const sx of [-1, 1]) {
        const pillar = new THREE.Mesh(new THREE.BoxGeometry(m.wid * 0.05, m.hei * 0.42, m.len * 0.045), wingMat);
        pillar.position.set(sx * wingW * 0.36, wingY - m.hei * 0.22, wingZ);
        g.add(pillar);
      }
    }
    if (m.wing === "dual") {
      const blade2 = new THREE.Mesh(new THREE.BoxGeometry(wingW * 0.9, m.hei * 0.055, m.len * 0.1), wingMat);
      blade2.position.set(0, wingY + m.hei * 0.24, wingZ + m.len * 0.02);
      blade2.rotation.x = -0.2;
      g.add(blade2);
    }
    if (m.wing === "swan") {
      const edge = new THREE.Mesh(
        new THREE.BoxGeometry(wingW * 1.01, m.hei * 0.02, m.len * 0.03),
        new THREE.MeshStandardMaterial({ color: skin.paintB, emissive: skin.paintB, emissiveIntensity: 1.6 }),
      );
      edge.position.set(0, wingY + m.hei * 0.045, wingZ - m.len * 0.05);
      g.add(edge);
    }
  }

  // ---- 后扩散器
  const diff = new THREE.Mesh(new THREE.BoxGeometry(m.wid * 0.9, m.hei * 0.22, m.len * 0.1), darkMat);
  diff.position.set(0, m.wheelR * 0.5, -m.len * 0.47);
  g.add(diff);
  for (let i = -2; i <= 2; i++) {
    const fin = new THREE.Mesh(
      new THREE.BoxGeometry(m.wid * 0.018, m.hei * 0.2, m.len * 0.1),
      new THREE.MeshStandardMaterial({ color: "#2b2f3a", metalness: 0.7, roughness: 0.4 }),
    );
    fin.position.set(i * m.wid * 0.16, m.wheelR * 0.5, -m.len * 0.47);
    g.add(fin);
  }

  // ---- T 级机甲装饰
  if (m.body === "mech" || m.tier === "T") {
    for (const sx of [-1, 1]) {
      const vane = new THREE.Mesh(
        new THREE.BoxGeometry(m.wid * 0.06, m.hei * 0.5, m.len * 0.3),
        new THREE.MeshStandardMaterial({ color: skin.paintB, emissive: skin.paintB, emissiveIntensity: 1.1, metalness: 0.9, roughness: 0.25 }),
      );
      vane.position.set(sx * m.wid * 0.52, m.hei * 1.0, -m.len * 0.16);
      vane.rotation.z = sx * 0.22;
      g.add(vane);
    }
  }

  // ---- 车轮
  const wheels: THREE.Group[] = [];
  const frontWheels: THREE.Group[] = [];
  const wz = m.len * 0.32;
  const wx = m.wid * 0.5;
  const rimColor = m.tier === "T" ? "#ffd166" : m.tier === "S" ? "#cfd6e4" : "#aab3c2";
  for (const [sx, sz] of [[-1, 1], [1, 1], [-1, -1], [1, -1]] as const) {
    const w = wheelMesh(m.wheelR, m.wid * 0.16, rimColor);
    w.position.set(sx * wx, m.wheelR, sz * wz);
    g.add(w);
    wheels.push(w);
    if (sz > 0) frontWheels.push(w);
  }

  // ---- 氮气尾焰
  const flames: THREE.Mesh[] = [];
  for (const sx of [-1, 1]) {
    const flame = new THREE.Mesh(
      new THREE.ConeGeometry(m.wid * 0.11, m.len * 0.5, 10, 1, true),
      new THREE.MeshBasicMaterial({ color: "#8fd8ff", transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }),
    );
    flame.rotation.x = Math.PI / 2;
    flame.position.set(sx * m.wid * 0.26, m.wheelR * 0.85, -m.len * 0.56);
    flame.visible = false;
    g.add(flame);
    flames.push(flame);
  }

  // ---- 底盘霓虹
  let underglow: THREE.PointLight | null = null;
  if (m.glow || skin.livery === "neon") {
    underglow = new THREE.PointLight(skin.paintB, 2.2, 7, 2);
    underglow.position.set(0, 0.2, 0);
    g.add(underglow);
    const strip = new THREE.Mesh(
      new THREE.PlaneGeometry(m.wid * 0.92, m.len * 0.86),
      new THREE.MeshBasicMaterial({ color: skin.paintB, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false }),
    );
    strip.rotation.x = -Math.PI / 2;
    strip.position.y = 0.06;
    g.add(strip);
  }

  return { group: g, wheels, frontWheels, flames, brakeMat, underglow, bodyMat, headMat };
}
