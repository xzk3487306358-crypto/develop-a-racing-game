import * as THREE from "three";

// ---------------------------------------------------------------------------
// 3D 赛道：真实空间样条曲线 + 采样帧（位置/切线/副法线/曲率/倾斜）
// ---------------------------------------------------------------------------

export interface TrackTheme {
  name: string;
  nameEn: string;
  difficulty: 1 | 2 | 3;
  desc: string;
  preview: [string, string];
  sky: [string, string, string];
  fog: string;
  fogDensity: number;
  ground: string;
  road: string;
  rumbleA: string;
  rumbleB: string;
  guard: string;
  guardEmissive: string;
  sun: string;
  sunIntensity: number;
  ambient: string;
  ambientIntensity: number;
  night: boolean;
  decor: "palm" | "neon" | "cactus" | "pine";
  decorColor: string;
  roadWidth: number;
}

export interface TrackDef {
  id: string;
  theme: TrackTheme;
  /** 控制点 [x, y, z] */
  points: [number, number, number][];
  /** 目标单圈长度（米），用于统一赛程时长 */
  target: number;
}

// ---------------------------------------------------------------- 形状生成器
function ring(n: number, rx: number, rz: number, fn: (a: number) => [number, number, number]): [number, number, number][] {
  const out: [number, number, number][] = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const [dx, dy, dz] = fn(a);
    out.push([Math.cos(a) * rx + dx, dy, Math.sin(a) * rz + dz]);
  }
  return out;
}

// 1) 落日海岸 —— 高速大椭圆 + 缓坡
const coastPts = ring(16, 320, 220, (a) => [Math.sin(a * 3) * 55, Math.sin(a * 2) * 9 + Math.sin(a * 5) * 4, Math.cos(a * 3) * 45]);

// 2) 霓虹夜城 —— 三叶草技术赛道，急弯多
const neonPts: [number, number, number][] = (() => {
  const out: [number, number, number][] = [];
  const n = 30;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const r = 190 + Math.cos(a * 3) * 130;
    out.push([Math.cos(a) * r, Math.sin(a * 4) * 7, Math.sin(a) * r]);
  }
  return out;
})();

// 3) 金色荒漠 —— 长直道 + 发夹弯
const desertPts: [number, number, number][] = [
  [-420, 0, -300], [-100, 3, -330], [240, 6, -320], [430, 10, -230],
  [470, 14, -80], [360, 12, 20], [180, 8, 40], [60, 6, 120],
  [120, 10, 260], [320, 16, 330], [430, 12, 450], [300, 6, 540],
  [40, 2, 520], [-180, 4, 470], [-330, 8, 360], [-430, 12, 200],
  [-470, 8, 30], [-460, 3, -140],
];

// 4) 雪岭天路 —— 大落差山道，连续急弯
const snowPts: [number, number, number][] = (() => {
  const out: [number, number, number][] = [];
  const n = 26;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const r = 230 + Math.sin(a * 2) * 90 + Math.cos(a * 5) * 45;
    out.push([Math.cos(a) * r, Math.sin(a * 1) * 42 + Math.sin(a * 3) * 16, Math.sin(a) * r * 0.85]);
  }
  return out;
})();

// 5) 天空竞技场 —— 大起伏 8 字感回路
const skyPts: [number, number, number][] = (() => {
  const out: [number, number, number][] = [];
  const n = 28;
  for (let i = 0; i < n; i++) {
    const t = (i / n) * Math.PI * 2;
    out.push([Math.sin(t) * 380, Math.sin(t * 2) * 34 + Math.cos(t * 3) * 14, Math.sin(t * 2) * 250]);
  }
  return out;
})();

export const TRACKS: TrackDef[] = [
  {
    id: "coast",
    target: 3400,
    points: coastPts,
    theme: {
      name: "落日海岸", nameEn: "Sunset Coast", difficulty: 1, desc: "高速大回环，适合练习连喷",
      preview: ["#ff8a3d", "#6b2d7a"],
      sky: ["#2b1055", "#c94b2b", "#ffb86b"], fog: "#e3803f", fogDensity: 0.0016,
      ground: "#2f8f42", road: "#4a4a55", rumbleA: "#f2f2f2", rumbleB: "#e03b3b",
      guard: "#d8d8de", guardEmissive: "#ff6a3d",
      sun: "#ffd9a0", sunIntensity: 2.4, ambient: "#7a5aa8", ambientIntensity: 1.5,
      night: false, decor: "palm", decorColor: "#2f9e57", roadWidth: 15,
    },
  },
  {
    id: "neon",
    target: 3050,
    points: neonPts,
    theme: {
      name: "霓虹夜城", nameEn: "Neon Night", difficulty: 2, desc: "三叶草技术弯，考验漂移",
      preview: ["#22d3ee", "#3b0764"],
      sky: ["#05061a", "#1a1046", "#3d1a5e"], fog: "#12082e", fogDensity: 0.0024,
      ground: "#141026", road: "#2b2b38", rumbleA: "#ff3ea5", rumbleB: "#22d3ee",
      guard: "#2a2a3d", guardEmissive: "#22d3ee",
      sun: "#9db8ff", sunIntensity: 1.1, ambient: "#4b3a8f", ambientIntensity: 1.9,
      night: true, decor: "neon", decorColor: "#ff3ea5", roadWidth: 14,
    },
  },
  {
    id: "desert",
    target: 4200,
    points: desertPts,
    theme: {
      name: "金色荒漠", nameEn: "Golden Desert", difficulty: 2, desc: "超长直道与发夹弯",
      preview: ["#ffc15e", "#a3452f"],
      sky: ["#3a1330", "#b2472f", "#ffc15e"], fog: "#dd9a55", fogDensity: 0.0015,
      ground: "#d9b26a", road: "#565059", rumbleA: "#f5ecd8", rumbleB: "#c04545",
      guard: "#b89a66", guardEmissive: "#ffb020",
      sun: "#ffdca8", sunIntensity: 2.8, ambient: "#a4703f", ambientIntensity: 1.4,
      night: false, decor: "cactus", decorColor: "#4d8a52", roadWidth: 16,
    },
  },
  {
    id: "snow",
    target: 2950,
    points: snowPts,
    theme: {
      name: "雪岭天路", nameEn: "Snow Ridge", difficulty: 3, desc: "大落差山道，冰面湿滑",
      preview: ["#e6f1f9", "#2b5a86"],
      sky: ["#0e2a4d", "#4f7fae", "#cfe4f5"], fog: "#cfe0ef", fogDensity: 0.0022,
      ground: "#e8eef6", road: "#63697a", rumbleA: "#ffffff", rumbleB: "#d94b4b",
      guard: "#cfdcea", guardEmissive: "#7dd3fc",
      sun: "#ffffff", sunIntensity: 2.2, ambient: "#8fb0cc", ambientIntensity: 1.8,
      night: false, decor: "pine", decorColor: "#3f6b5f", roadWidth: 14,
    },
  },
  {
    id: "sky",
    target: 3350,
    points: skyPts,
    theme: {
      name: "天空竞技场", nameEn: "Sky Arena", difficulty: 3, desc: "悬空赛道，剧烈起伏",
      preview: ["#a78bfa", "#0ea5e9"],
      sky: ["#0b1030", "#3b2f8f", "#8ec5ff"], fog: "#243a7a", fogDensity: 0.0018,
      ground: "#1a2140", road: "#3a3f57", rumbleA: "#e9d5ff", rumbleB: "#a855f7",
      guard: "#4b3f7a", guardEmissive: "#a78bfa",
      sun: "#dbeafe", sunIntensity: 2.0, ambient: "#5b6fd8", ambientIntensity: 2.0,
      night: true, decor: "neon", decorColor: "#a78bfa", roadWidth: 15,
    },
  },
];

// ---------------------------------------------------------------- 采样帧
export interface Frame {
  pos: THREE.Vector3;
  tan: THREE.Vector3;
  bin: THREE.Vector3; // 横向（右）
  nor: THREE.Vector3; // 路面法线
  curv: number;
  bank: number;
}

export class TrackPath {
  curve: THREE.CatmullRomCurve3;
  frames: Frame[] = [];
  cum: number[] = [];
  length = 0;
  readonly samples: number;
  roadWidth: number;

  constructor(def: TrackDef, samples = 1400) {
    this.samples = samples;
    this.roadWidth = def.theme.roadWidth;
    const mk = (k: number) => new THREE.CatmullRomCurve3(
      def.points.map((p) => new THREE.Vector3(p[0] * k, p[1] * k, p[2] * k)), true, "catmullrom", 0.5,
    );
    // 先按原始尺寸测长，再缩放到目标单圈长度，统一各图赛程时长
    this.curve = mk(1);
    this.build();
    const k = (def.target || this.length) / this.length;
    if (Math.abs(k - 1) > 0.01) {
      this.frames = [];
      this.cum = [];
      this.curve = mk(k);
      this.build();
    }
  }

  private build() {
    const N = this.samples;
    const pts: THREE.Vector3[] = [];
    const tans: THREE.Vector3[] = [];
    for (let i = 0; i < N; i++) {
      const t = i / N;
      pts.push(this.curve.getPoint(t));
      tans.push(this.curve.getTangent(t).normalize());
    }
    // 累计弧长
    this.cum = [0];
    let total = 0;
    for (let i = 0; i < N; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % N];
      total += a.distanceTo(b);
      this.cum.push(total);
    }
    this.length = total;

    const up = new THREE.Vector3(0, 1, 0);
    for (let i = 0; i < N; i++) {
      const tan = tans[i];
      const bin = new THREE.Vector3().crossVectors(tan, up).normalize();
      // 曲率：相邻切线夹角带符号
      const nt = tans[(i + 1) % N];
      const cross = new THREE.Vector3().crossVectors(tan, nt);
      const curv = Math.asin(THREE.MathUtils.clamp(cross.y, -1, 1)) * 60;
      const bank = THREE.MathUtils.clamp(-curv * 0.16, -0.32, 0.32);
      // 倾斜后的法线与副法线
      const q = new THREE.Quaternion().setFromAxisAngle(tan, bank);
      const bin2 = bin.clone().applyQuaternion(q);
      const nor = new THREE.Vector3().crossVectors(bin2, tan).normalize();
      this.frames.push({ pos: pts[i], tan, bin: bin2, nor, curv, bank });
    }
    // 曲率平滑
    const raw = this.frames.map((f) => f.curv);
    for (let i = 0; i < N; i++) {
      let sum = 0;
      for (let k = -4; k <= 4; k++) sum += raw[(i + k + N) % N];
      this.frames[i].curv = sum / 9;
    }
  }

  /** 弧长 → 采样索引（浮点） */
  idxAt(s: number) {
    const L = this.length;
    let d = ((s % L) + L) % L;
    // 二分查找
    let lo = 0;
    let hi = this.cum.length - 1;
    while (lo < hi - 1) {
      const mid = (lo + hi) >> 1;
      if (this.cum[mid] <= d) lo = mid;
      else hi = mid;
    }
    const span = Math.max(1e-6, this.cum[lo + 1] - this.cum[lo]);
    return lo + (d - this.cum[lo]) / span;
  }

  frameAt(s: number, out?: Frame): Frame {
    const N = this.samples;
    const fi = this.idxAt(s);
    const i0 = Math.floor(fi) % N;
    const i1 = (i0 + 1) % N;
    const f = fi - Math.floor(fi);
    const a = this.frames[i0];
    const b = this.frames[i1];
    const r: Frame = out ?? {
      pos: new THREE.Vector3(), tan: new THREE.Vector3(), bin: new THREE.Vector3(),
      nor: new THREE.Vector3(), curv: 0, bank: 0,
    };
    r.pos.lerpVectors(a.pos, b.pos, f);
    r.tan.lerpVectors(a.tan, b.tan, f).normalize();
    r.bin.lerpVectors(a.bin, b.bin, f).normalize();
    r.nor.lerpVectors(a.nor, b.nor, f).normalize();
    r.curv = a.curv + (b.curv - a.curv) * f;
    r.bank = a.bank + (b.bank - a.bank) * f;
    return r;
  }

  /** 世界坐标：弧长 s + 横向偏移 lat + 高度 h */
  posAt(s: number, lat: number, h = 0, out?: THREE.Vector3) {
    const fr = this.frameAt(s, this._tmp);
    const v = out ?? new THREE.Vector3();
    v.copy(fr.pos).addScaledVector(fr.bin, lat).addScaledVector(fr.nor, h);
    return v;
  }

  private _tmp: Frame = {
    pos: new THREE.Vector3(), tan: new THREE.Vector3(), bin: new THREE.Vector3(),
    nor: new THREE.Vector3(), curv: 0, bank: 0,
  };

  /** 环形弧长差（-L/2 .. L/2） */
  delta(a: number, b: number) {
    const L = this.length;
    let d = a - b;
    while (d > L / 2) d -= L;
    while (d < -L / 2) d += L;
    return d;
  }
}
