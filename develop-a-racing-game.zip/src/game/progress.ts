// ---------------------------------------------------------------------------
// 成长系统：金币、改装、驾照、成就、幽灵车、房间排行榜
// ---------------------------------------------------------------------------

const KEY = "sunset-gp-save-v2";

export type PartId = "engine" | "nitro" | "tyre" | "turbo" | "frame";

export interface PartDef {
  id: PartId;
  name: string;
  desc: string;
  icon: string;
  /** 每级加成 */
  per: number;
  costs: number[];
}

export const PARTS: PartDef[] = [
  { id: "engine", name: "引擎", desc: "极速 +2%/级", icon: "⚙️", per: 0.02, costs: [200, 450, 900, 1600, 2600] },
  { id: "nitro", name: "氮气瓶", desc: "喷射时长 +8%/级", icon: "💨", per: 0.08, costs: [180, 400, 820, 1500, 2400] },
  { id: "tyre", name: "轮胎", desc: "抓地 +5%/级", icon: "🛞", per: 0.05, costs: [160, 380, 780, 1400, 2300] },
  { id: "turbo", name: "涡轮", desc: "加速 +5%/级", icon: "🌀", per: 0.05, costs: [180, 420, 850, 1500, 2450] },
  { id: "frame", name: "车架", desc: "碰撞损失 -10%/级", icon: "🔩", per: 0.1, costs: [150, 350, 700, 1300, 2200] },
];

export const MAX_PART_LEVEL = 5;

export interface LicenseTest {
  id: string;
  grade: "C" | "B" | "A" | "S";
  name: string;
  brief: string;
  /** 目标类型 */
  goal:
    | { type: "drift"; count: number }
    | { type: "mini"; count: number }
    | { type: "double"; count: number }
    | { type: "perfect"; count: number }
    | { type: "wc"; count: number }
    | { type: "link"; count: number }
    | { type: "combo"; count: number }
    | { type: "lapTime"; seconds: number }
    | { type: "clean"; seconds: number };
  reward: number;
  trackId: string;
}

export const LICENSES: LicenseTest[] = [
  { id: "c1", grade: "C", name: "起步基础", brief: "完成 3 次漂移", goal: { type: "drift", count: 3 }, reward: 150, trackId: "coast" },
  { id: "c2", grade: "C", name: "初识喷射", brief: "触发 3 次小喷", goal: { type: "mini", count: 3 }, reward: 200, trackId: "coast" },
  { id: "b1", grade: "B", name: "双喷入门", brief: "触发 3 次双喷", goal: { type: "double", count: 3 }, reward: 300, trackId: "desert" },
  { id: "b2", grade: "B", name: "节奏掌控", brief: "触发 2 次完美双喷", goal: { type: "perfect", count: 2 }, reward: 420, trackId: "desert" },
  { id: "a1", grade: "A", name: "WC 喷精通", brief: "触发 2 次 WC 喷", goal: { type: "wc", count: 2 }, reward: 560, trackId: "neon" },
  { id: "a2", grade: "A", name: "衔接大师", brief: "触发 2 次 LINK 喷", goal: { type: "link", count: 2 }, reward: 680, trackId: "neon" },
  { id: "s1", grade: "S", name: "连喷极限", brief: "达成 5 连喷", goal: { type: "combo", count: 5 }, reward: 900, trackId: "snow" },
  { id: "s2", grade: "S", name: "无损竞速", brief: "60 秒内零碰撞行驶", goal: { type: "clean", seconds: 60 }, reward: 1200, trackId: "snow" },
];

export interface Achievement {
  id: string;
  name: string;
  desc: string;
  reward: number;
}

export const ACHIEVEMENTS: Achievement[] = [
  { id: "first_win", name: "首胜", desc: "竞速赛拿到 P1", reward: 300 },
  { id: "combo5", name: "连喷高手", desc: "单局达成 5 连喷", reward: 250 },
  { id: "perfect10", name: "节奏之神", desc: "累计 10 次完美双喷", reward: 400 },
  { id: "no_crash", name: "一尘不染", desc: "零碰撞完赛", reward: 350 },
  { id: "speed300", name: "破 300", desc: "时速突破 300 km/h", reward: 200 },
  { id: "item_master", name: "道具达人", desc: "累计使用 20 个道具", reward: 300 },
  { id: "survivor", name: "生存王者", desc: "淘汰赛中获胜", reward: 500 },
  { id: "all_tracks", name: "环游四方", desc: "四张赛道各完赛一次", reward: 400 },
];

export interface GhostFrame {
  t: number;
  z: number;
  x: number;
}

export interface SaveData {
  coins: number;
  tuning: Record<PartId, number>;
  licenses: string[];
  achievements: string[];
  stats: { races: number; wins: number; perfects: number; items: number; crashes: number; distance: number };
  tracksDone: string[];
  ghosts: Record<string, GhostFrame[]>;
  bestTimes: Record<string, number>;
  rooms: Record<string, { name: string; time: number; position: number; date: number }[]>;
}

export const emptySave = (): SaveData => ({
  coins: 500,
  tuning: { engine: 0, nitro: 0, tyre: 0, turbo: 0, frame: 0 },
  licenses: [],
  achievements: [],
  stats: { races: 0, wins: 0, perfects: 0, items: 0, crashes: 0, distance: 0 },
  tracksDone: [],
  ghosts: {},
  bestTimes: {},
  rooms: {},
});

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return emptySave();
    const parsed = JSON.parse(raw);
    const base = emptySave();
    return {
      ...base,
      ...parsed,
      tuning: { ...base.tuning, ...(parsed.tuning ?? {}) },
      stats: { ...base.stats, ...(parsed.stats ?? {}) },
      ghosts: parsed.ghosts ?? {},
      bestTimes: parsed.bestTimes ?? {},
      rooms: parsed.rooms ?? {},
      licenses: parsed.licenses ?? [],
      achievements: parsed.achievements ?? [],
      tracksDone: parsed.tracksDone ?? [],
    };
  } catch {
    return emptySave();
  }
}

export function saveSave(d: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(d));
  } catch {
    /* quota */
  }
}

export function tuningBonus(t: Record<PartId, number>) {
  return {
    speed: 1 + (t.engine ?? 0) * 0.02,
    nitro: 1 + (t.nitro ?? 0) * 0.08,
    grip: 1 + (t.tyre ?? 0) * 0.05,
    accel: 1 + (t.turbo ?? 0) * 0.05,
    frame: 1 - (t.frame ?? 0) * 0.1,
  };
}

export function licenseGrade(done: string[]): string {
  const grades: Array<"S" | "A" | "B" | "C"> = ["S", "A", "B", "C"];
  for (const g of grades) {
    const tests = LICENSES.filter((l) => l.grade === g);
    if (tests.every((t) => done.includes(t.id))) return `${g} 照`;
  }
  return "无照";
}
