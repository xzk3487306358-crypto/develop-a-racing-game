// 基于 Web Audio 的简易音效：引擎轰鸣、漂移胎啸、氮气呼啸、碰撞、提示音
export class GameAudio {
  private ctx: AudioContext | null = null;
  private osc: OscillatorNode | null = null;
  private osc2: OscillatorNode | null = null;
  private gain: GainNode | null = null;
  private filter: BiquadFilterNode | null = null;
  private master: GainNode | null = null;
  private driftGain: GainNode | null = null;
  private driftFilter: BiquadFilterNode | null = null;
  muted = false;

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.5;
    this.master.connect(this.ctx.destination);

    this.filter = this.ctx.createBiquadFilter();
    this.filter.type = "lowpass";
    this.filter.frequency.value = 600;
    this.filter.connect(this.master);

    this.gain = this.ctx.createGain();
    this.gain.gain.value = 0;
    this.gain.connect(this.filter);

    this.osc = this.ctx.createOscillator();
    this.osc.type = "sawtooth";
    this.osc.frequency.value = 50;
    this.osc.connect(this.gain);
    this.osc.start();

    this.osc2 = this.ctx.createOscillator();
    this.osc2.type = "square";
    this.osc2.frequency.value = 25;
    const g2 = this.ctx.createGain();
    g2.gain.value = 0.4;
    this.osc2.connect(g2);
    g2.connect(this.gain);
    this.osc2.start();

    // ---- 漂移胎啸：循环白噪声 -> 带通 -> 增益 ----
    const noiseLen = 2;
    const buf = this.ctx.createBuffer(1, Math.floor(this.ctx.sampleRate * noiseLen), this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    this.driftFilter = this.ctx.createBiquadFilter();
    this.driftFilter.type = "bandpass";
    this.driftFilter.frequency.value = 1600;
    this.driftFilter.Q.value = 0.9;
    this.driftGain = this.ctx.createGain();
    this.driftGain.gain.value = 0;
    src.connect(this.driftFilter);
    this.driftFilter.connect(this.driftGain);
    this.driftGain.connect(this.master);
    src.start();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.5, this.ctx.currentTime, 0.05);
  }

  /** 引擎声：speedPercent 0..1，boosting 是否氮气喷射中 */
  setEngine(speedPercent: number, accelerating: boolean, active: boolean, boosting = false) {
    if (!this.ctx || !this.osc || !this.osc2 || !this.gain || !this.filter) return;
    const t = this.ctx.currentTime;
    const gear = Math.min(4, Math.floor(speedPercent * 5));
    const inGear = speedPercent * 5 - gear;
    let base = 45 + gear * 12 + inGear * 70;
    if (boosting) base *= 1.28;
    this.osc.frequency.setTargetAtTime(base, t, 0.08);
    this.osc2.frequency.setTargetAtTime(base / 2, t, 0.08);
    this.filter.frequency.setTargetAtTime(400 + speedPercent * 1400 + (accelerating ? 300 : 0) + (boosting ? 500 : 0), t, 0.1);
    const vol = active ? 0.08 + speedPercent * 0.12 + (accelerating ? 0.04 : 0) + (boosting ? 0.05 : 0) : 0;
    this.gain.gain.setTargetAtTime(vol, t, 0.1);
  }

  /** 漂移胎啸开关 + 强度 0..1 */
  setDrift(active: boolean, intensity = 0.6) {
    if (!this.ctx || !this.driftGain || !this.driftFilter) return;
    const t = this.ctx.currentTime;
    this.driftGain.gain.setTargetAtTime(active ? 0.06 + 0.12 * intensity : 0, t, 0.05);
    this.driftFilter.frequency.setTargetAtTime(1100 + intensity * 1700, t, 0.1);
  }

  /** 氮气 / 小喷 呼啸 */
  nos(power = 1) {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const len = 0.65 * power + 0.15;
    const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * len), ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const f = ctx.createBiquadFilter();
    f.type = "bandpass";
    f.Q.value = 1.2;
    f.frequency.setValueAtTime(500, ctx.currentTime);
    f.frequency.exponentialRampToValueAtTime(4200, ctx.currentTime + len * 0.7);
    f.frequency.exponentialRampToValueAtTime(900, ctx.currentTime + len);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.5 * power, ctx.currentTime + 0.06);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + len);
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start();
  }

  crash() {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const len = 0.35;
    const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * len), ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 2);
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const g = ctx.createGain();
    g.gain.value = 0.6;
    const f = ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 900;
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start();
  }

  beep(freq = 880, dur = 0.12, type: OscillatorType = "square") {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.25, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
    o.connect(g);
    g.connect(this.master);
    o.start();
    o.stop(ctx.currentTime + dur);
  }

  /** 完美判定：金属质感上扬和弦 */
  perfect() {
    this.nos(1.15);
    [1046, 1568, 2093].forEach((f, i) => setTimeout(() => this.beep(f, 0.14, "triangle"), i * 55));
  }

  /** 道具获得 */
  itemGet() {
    [660, 880, 1100].forEach((f, i) => setTimeout(() => this.beep(f, 0.08, "square"), i * 60));
  }

  /** 爆炸 */
  explode() {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const len = 0.5;
    const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * len), ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 1.4);
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const f = ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(1800, ctx.currentTime);
    f.frequency.exponentialRampToValueAtTime(120, ctx.currentTime + len);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.8, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + len);
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start();
  }

  /** 护盾抵挡 */
  shield() {
    [1400, 1000, 1600].forEach((f, i) => setTimeout(() => this.beep(f, 0.1, "sine"), i * 45));
  }

  /** 加速带 */
  pad() {
    this.beep(520, 0.07, "sawtooth");
    setTimeout(() => this.beep(1040, 0.12, "sawtooth"), 55);
  }

  /** 落地 */
  land(big: boolean) {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const len = big ? 0.28 : 0.16;
    const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * len), ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 2.2);
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const f = ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = big ? 420 : 620;
    const g = ctx.createGain();
    g.gain.value = big ? 0.7 : 0.45;
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start();
  }

  /** 淘汰警报 */
  alarm() {
    this.beep(320, 0.16, "square");
    setTimeout(() => this.beep(240, 0.2, "square"), 170);
  }

  lapChime() {
    this.beep(660, 0.12);
    setTimeout(() => this.beep(880, 0.12), 120);
    setTimeout(() => this.beep(1320, 0.2), 240);
  }

  finishFanfare() {
    [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => this.beep(f, 0.25, "triangle"), i * 150));
  }
}
