// ---------------------------------------------------------------------------
// 道具赛系统：8 种道具 + 名次补偿抽取
// ---------------------------------------------------------------------------

export type ItemId = "banana" | "mine" | "missile" | "water" | "magnet" | "shield" | "lightning" | "warp" | "ghost";

export interface ItemDef {
  id: ItemId;
  name: string;
  emoji: string;
  desc: string;
  color: string;
  /** 名次权重：index 0 = 第1名，越靠后越容易吃到强道具 */
  weights: number[];
}

// 权重表按 8 人赛设计（不足 8 人自动取最后一档）
export const ITEMS: Record<ItemId, ItemDef> = {
  banana: {
    id: "banana", name: "香蕉皮", emoji: "🍌", desc: "身后放置，撞到会打滑失控", color: "#facc15",
    weights: [34, 26, 20, 16, 12, 8, 6, 4],
  },
  mine: {
    id: "mine", name: "地雷", emoji: "💣", desc: "身后放置，触发后强力减速", color: "#f97316",
    weights: [22, 22, 20, 18, 14, 10, 8, 6],
  },
  shield: {
    id: "shield", name: "护盾", emoji: "🛡️", desc: "抵挡一次攻击，持续 8 秒", color: "#38bdf8",
    weights: [20, 18, 18, 16, 14, 12, 10, 8],
  },
  missile: {
    id: "missile", name: "追踪导弹", emoji: "🚀", desc: "锁定前方一名对手并命中", color: "#ef4444",
    weights: [6, 10, 14, 18, 20, 22, 22, 20],
  },
  water: {
    id: "water", name: "水弹", emoji: "💧", desc: "遮挡前方所有对手视野", color: "#22d3ee",
    weights: [6, 10, 12, 14, 16, 16, 16, 14],
  },
  magnet: {
    id: "magnet", name: "磁铁", emoji: "🧲", desc: "3 秒内被前车拖拽加速", color: "#a78bfa",
    weights: [4, 6, 8, 10, 12, 14, 14, 14],
  },
  warp: {
    id: "warp", name: "时空隧道", emoji: "🌀", desc: "瞬间前移一段距离", color: "#c084fc",
    weights: [2, 4, 6, 8, 10, 12, 14, 16],
  },
  lightning: {
    id: "lightning", name: "闪电", emoji: "⚡", desc: "全场对手减速并失控", color: "#fde047",
    weights: [0, 2, 2, 4, 6, 10, 14, 18],
  },
  ghost: {
    id: "ghost", name: "幽灵", emoji: "👻", desc: "5 秒无视碰撞穿透一切", color: "#e2e8f0",
    weights: [6, 8, 10, 12, 12, 12, 10, 8],
  },
};

export const ITEM_LIST = Object.values(ITEMS);

/** 按名次抽取道具（名次从 1 开始） */
export function drawItem(position: number, racers: number, rand: () => number): ItemId {
  const idx = Math.min(7, Math.max(0, Math.round(((position - 1) / Math.max(1, racers - 1)) * 7)));
  const pool: { id: ItemId; w: number }[] = ITEM_LIST.map((it) => ({ id: it.id, w: it.weights[idx] ?? 1 }));
  const total = pool.reduce((s, p) => s + p.w, 0);
  let r = rand() * total;
  for (const p of pool) {
    if (r < p.w) return p.id;
    r -= p.w;
  }
  return "banana";
}

/** 道具是否为"立即生效"型（无需瞄准） */
export const INSTANT_ITEMS: ItemId[] = ["shield", "lightning", "magnet", "warp", "ghost", "water"];
