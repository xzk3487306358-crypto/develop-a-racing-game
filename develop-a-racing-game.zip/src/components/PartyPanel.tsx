import { useState } from "react";
import { cn } from "../utils/cn";
import { Check, Copy, LogIn, Plus, RefreshCw, UserPlus, Users, X } from "lucide-react";

export interface Party {
  code: string;
  members: string[]; // 队友（不含玩家）
}

const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
export const randomCode = () => Array.from({ length: 6 }, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join("");
export const codeToSeed = (code: string) => {
  let h = 2166136261;
  for (let i = 0; i < code.length; i++) {
    h ^= code.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
};

export default function PartyPanel({ party, onChange }: { party: Party; onChange: (p: Party) => void }) {
  const [name, setName] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [copied, setCopied] = useState(false);

  const addMember = () => {
    const n = name.trim();
    if (!n || party.members.length >= 3 || party.members.includes(n)) return;
    onChange({ ...party, members: [...party.members, n] });
    setName("");
  };

  const copy = () => {
    navigator.clipboard?.writeText(party.code).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  };

  return (
    <div className="space-y-2.5 text-left">
      {/* 房间码 */}
      <div className="rounded-xl border border-cyan-400/25 bg-cyan-400/10 p-2.5">
        <div className="mb-1 flex items-center justify-between">
          <span className="flex items-center gap-1 text-[10px] tracking-widest text-cyan-200/80 uppercase">
            <Users className="h-3 w-3" /> 房间号
          </span>
          <div className="flex gap-1">
            <button onClick={() => onChange({ ...party, code: randomCode() })} className="rounded-md bg-white/10 p-1 text-white/70 transition hover:bg-white/20" title="换一个">
              <RefreshCw className="h-3 w-3" />
            </button>
            <button onClick={copy} className="rounded-md bg-white/10 p-1 text-white/70 transition hover:bg-white/20" title="复制房间号">
              {copied ? <Check className="h-3 w-3 text-lime-300" /> : <Copy className="h-3 w-3" />}
            </button>
          </div>
        </div>
        <div className="font-mono text-2xl font-black tracking-[0.3em] text-cyan-200 sm:text-3xl">{party.code}</div>
        <p className="mt-1 text-[9px] leading-relaxed text-white/50 sm:text-[10px]">
          相同房间号 = 相同赛道种子与对手阵容。把房间号发给好友，各自跑同一场比赛后比拼成绩。
        </p>
      </div>

      {/* 加入房间 */}
      <div className="flex gap-1.5">
        <input
          value={joinCode}
          onChange={(e) => setJoinCode(e.target.value.toUpperCase().slice(0, 6))}
          placeholder="输入好友房间号"
          className="min-w-0 flex-1 rounded-lg border border-white/15 bg-black/40 px-2 py-1.5 font-mono text-xs tracking-widest text-white placeholder:text-white/25 focus:border-cyan-400/60 focus:outline-none"
        />
        <button
          onClick={() => {
            if (joinCode.length >= 4) {
              onChange({ ...party, code: joinCode });
              setJoinCode("");
            }
          }}
          className="flex items-center gap-1 rounded-lg bg-cyan-500/80 px-2.5 py-1.5 text-xs font-bold text-white transition hover:bg-cyan-400"
        >
          <LogIn className="h-3.5 w-3.5" />
          加入
        </button>
      </div>

      {/* 队友 */}
      <div>
        <div className="mb-1 flex items-center gap-1 text-[10px] tracking-widest text-white/50 uppercase">
          <UserPlus className="h-3 w-3" /> 我的队友（{party.members.length}/3）
        </div>
        <div className="flex gap-1.5">
          <input
            value={name}
            onChange={(e) => setName(e.target.value.slice(0, 8))}
            onKeyDown={(e) => e.key === "Enter" && addMember()}
            placeholder="好友昵称"
            className="min-w-0 flex-1 rounded-lg border border-white/15 bg-black/40 px-2 py-1.5 text-xs text-white placeholder:text-white/25 focus:border-fuchsia-400/60 focus:outline-none"
          />
          <button onClick={addMember} className="flex items-center gap-1 rounded-lg bg-fuchsia-500/80 px-2.5 py-1.5 text-xs font-bold text-white transition hover:bg-fuchsia-400">
            <Plus className="h-3.5 w-3.5" />
            添加
          </button>
        </div>
        <div className="mt-1.5 flex flex-wrap gap-1.5">
          <span className="flex items-center gap-1 rounded-full border border-lime-300/40 bg-lime-300/15 px-2 py-0.5 text-[10px] font-bold text-lime-200">你（队长）</span>
          {party.members.map((m) => (
            <span key={m} className="flex items-center gap-1 rounded-full border border-cyan-300/40 bg-cyan-300/15 px-2 py-0.5 text-[10px] font-bold text-cyan-100">
              {m}
              <button onClick={() => onChange({ ...party, members: party.members.filter((x) => x !== m) })} className="text-white/50 transition hover:text-white">
                <X className="h-2.5 w-2.5" />
              </button>
            </span>
          ))}
          {party.members.length === 0 && <span className={cn("text-[10px] text-white/35")}>还没有队友，添加后与 AI 车队对抗</span>}
        </div>
      </div>
    </div>
  );
}
