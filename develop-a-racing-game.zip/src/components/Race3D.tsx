import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Engine3D, STEP, TRACKS, type Hud3D, type Keys, type RaceMode, type Standing } from "../game3d/engine3d";
import { CAR_MODELS, LIVERIES, defaultSkin3D, type CarSkin3D } from "../game3d/carModels";
import { ITEMS } from "../game/items";
import { ACHIEVEMENTS, LICENSES, PARTS, loadSave, saveSave, tuningBonus, type PartId, type SaveData } from "../game/progress";
import { GameAudio } from "../game/audio";
import { ItemCodex, LicensePanel, RoomBoard, StatsPanel, TuningPanel } from "./ProgressPanels";
import Garage3D from "./Garage3D";
import PartyPanel, { codeToSeed, randomCode, type Party } from "./PartyPanel";
import { cn } from "../utils/cn";
import {
  Award, Bomb, ChevronLeft, ChevronRight, Coins, Flag, Flame, Ghost, Heart, Home, Map as MapIcon,
  Pause, Play, RotateCcw, Skull, Sparkles, Star, Timer, Trophy, Users, Volume2, VolumeX, Wind, Zap,
} from "lucide-react";

const BEST_KEY = "sunset-gp3d-best";
const SKIN_KEY = "sunset-gp3d-skin";

function fmt(t: number | null | undefined) {
  if (t === null || t === undefined) return "--:--.---";
  const m = Math.floor(t / 60), s = Math.floor(t % 60), ms = Math.floor((t * 1000) % 1000);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String(ms).padStart(3, "0")}`;
}

const MODES: { id: RaceMode; name: string; desc: string; icon: typeof Timer }[] = [
  { id: "race", name: "竞速对战", desc: "与 7 名 AI 争 P1", icon: Trophy },
  { id: "item", name: "道具赛", desc: "导弹闪电大乱斗", icon: Bomb },
  { id: "elim", name: "淘汰赛", desc: "20 秒淘汰末位", icon: Skull },
  { id: "time", name: "计时挑战", desc: "幽灵车刷圈速", icon: Timer },
  { id: "team", name: "好友组队", desc: "车队对抗 AI", icon: Users },
];

const emptyHud = (): Hud3D => ({
  phase: "menu", speedKmh: 0, speedPct: 0, lap: 1, totalLaps: 3, lapTime: 0, lastLap: null, bestLap: null, totalTime: 0,
  hp: 100, maxHp: 100, hpFlash: 0, countdown: 3, goTimer: 0, introT: 0,
  drifting: false, driftTime: 0, charge: 0, cans: 1, boost: 0, boostLabel: "", boostSeq: 0, combo: 0,
  dblWindow: 0, dblPerfect: [0.28, 0.62], wcArmed: false, linkReady: false, airborne: false, offroad: false, paused: false,
  mode: "race", position: 1, totalRacers: 8, standings: [], teamScore: 0, rivalScore: 0,
  itemsEnabled: false, item: null, itemRolling: false, itemFlash: "", shieldT: 0, ghostT: 0,
  elimTimer: 0, elimWarn: false, elimCount: 0, eliminated: false, licenseProgress: 0, trackId: "coast",
  mapPlayer: { x: 0.5, y: 0.5 }, mapRivals: [], mapPath: [],
});

interface Results {
  lapTimes: number[]; totalTime: number; bestLapTime: number | null; maxSpeedKmh: number;
  bestCombo: number; perfectCount: number; position: number; totalRacers: number; standings: Standing[];
  mode: RaceMode; teamScore: number; rivalScore: number; eliminated: boolean; elimCount: number;
  licensePassed: boolean; itemsUsed: number; crashes: number; distance: number; hp: number;
  counters: { drift: number; mini: number; double: number; perfect: number; wc: number; link: number; crashes: number; cleanTime: number };
}

export default function Race3D() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const engRef = useRef<Engine3D | null>(null);
  const audioRef = useRef(new GameAudio());
  const [hud, setHud] = useState<Hud3D>(emptyHud);
  const [muted, setMuted] = useState(false);
  const [trackId, setTrackId] = useState("coast");
  const [mode, setMode] = useState<RaceMode>("race");
  const [laps, setLaps] = useState(3);
  const [tab, setTab] = useState<"track" | "garage" | "tune" | "license" | "party" | "stats">("track");
  const [skin, setSkin] = useState<CarSkin3D>(() => {
    const d = defaultSkin3D();
    try {
      const raw = localStorage.getItem(SKIN_KEY);
      if (!raw) return d;
      const p = JSON.parse(raw);
      const model = CAR_MODELS.find((m) => m.id === p?.model?.id) ?? d.model;
      const livery = LIVERIES.some((l) => l.id === p?.livery) ? p.livery : d.livery;
      return {
        model,
        livery,
        paintA: typeof p?.paintA === "string" ? p.paintA : d.paintA,
        paintB: typeof p?.paintB === "string" ? p.paintB : d.paintB,
      };
    } catch {
      return d;
    }
  });
  const [party, setParty] = useState<Party>({ code: randomCode(), members: [] });
  const [best, setBest] = useState<number | null>(() => { const v = localStorage.getItem(BEST_KEY); return v ? Number(v) : null; });
  const [isNewRecord, setIsNewRecord] = useState(false);
  const [results, setResults] = useState<Results | null>(null);
  const [save, setSave] = useState<SaveData>(() => loadSave());
  const [earned, setEarned] = useState<{ coins: number; unlocked: string[] }>({ coins: 0, unlocked: [] });
  const [activeLicense, setActiveLicense] = useState<string | null>(null);
  const [useGhost, setUseGhost] = useState(true);
  const [ready, setReady] = useState(false);
  const saveRef = useRef(save);
  saveRef.current = save;
  const licRef = useRef(activeLicense);
  licRef.current = activeLicense;

  // ------------------------------------------------------------ 奖励
  const applyRewards = useCallback((eng: Engine3D, r: Results) => {
    const prev = saveRef.current;
    const next: SaveData = {
      ...prev, tuning: { ...prev.tuning }, stats: { ...prev.stats }, ghosts: { ...prev.ghosts },
      bestTimes: { ...prev.bestTimes }, rooms: { ...prev.rooms },
      licenses: [...prev.licenses], achievements: [...prev.achievements], tracksDone: [...prev.tracksDone],
    };
    const unlocked: string[] = [];
    let coins = 60;
    if (r.mode !== "time" && r.mode !== "license") coins += Math.max(0, r.totalRacers - r.position + 1) * 25;
    coins += r.bestCombo * 12 + r.perfectCount * 30;
    if (r.eliminated) coins = Math.max(30, Math.round(coins * 0.4));

    const lic = licRef.current;
    if (r.licensePassed && lic && !next.licenses.includes(lic)) {
      const t = LICENSES.find((l) => l.id === lic);
      if (t) { next.licenses.push(lic); coins += t.reward; unlocked.push(`驾照：${t.name}`); }
    }
    next.stats.races++;
    next.stats.perfects += r.perfectCount;
    next.stats.items += r.itemsUsed;
    next.stats.crashes += r.crashes;
    next.stats.distance += r.distance;
    if (r.mode !== "time" && r.position === 1 && !r.eliminated) next.stats.wins++;
    if (!next.tracksDone.includes(eng.trackId)) next.tracksDone.push(eng.trackId);

    const grant = (id: string) => {
      if (next.achievements.includes(id)) return;
      const a = ACHIEVEMENTS.find((x) => x.id === id);
      if (!a) return;
      next.achievements.push(id); coins += a.reward; unlocked.push(`成就：${a.name}`);
    };
    if (r.mode !== "time" && r.position === 1 && !r.eliminated) grant("first_win");
    if (r.bestCombo >= 5) grant("combo5");
    if (next.stats.perfects >= 10) grant("perfect10");
    if (r.crashes === 0) grant("no_crash");
    if (r.maxSpeedKmh >= 300) grant("speed300");
    if (next.stats.items >= 20) grant("item_master");
    if (r.mode === "elim" && !r.eliminated) grant("survivor");
    if (next.tracksDone.length >= 4) grant("all_tracks");
    next.coins += coins;

    const gk = `${eng.trackId}:${eng.totalLaps}`;
    if (!r.eliminated && (!next.bestTimes[gk] || r.totalTime < next.bestTimes[gk])) {
      next.bestTimes[gk] = r.totalTime;
      const rec = eng.getGhostRecording();
      if (rec.length > 4) next.ghosts[eng.trackId] = rec;
    }
    const rk = `${eng.roomCode}:${eng.trackId}`;
    const board = [...(next.rooms[rk] ?? [])].filter((e) => e.name !== "你");
    board.push({ name: "你", time: r.totalTime, position: r.position, date: Date.now() });
    next.rooms[rk] = board.slice(-12);

    saveSave(next);
    setSave(next);
    setEarned({ coins, unlocked });
  }, []);

  // ------------------------------------------------------------ 主循环
  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    let eng: Engine3D;
    try {
      eng = new Engine3D(cv);
    } catch (e) {
      console.error("WebGL 初始化失败", e);
      return;
    }
    engRef.current = eng;
    const audio = audioRef.current;
    eng.setSkin(skin);
    eng.tuning = tuningBonus(saveRef.current.tuning);
    setReady(true);

    eng.onCrash = () => audio.crash();
    eng.onDamage = () => audio.beep(220, 0.08, "square");
    eng.onLap = () => audio.lapChime();
    eng.onNos = () => audio.nos(1);
    eng.onMiniBoost = () => audio.nos(0.55);
    eng.onPerfect = () => audio.perfect();
    eng.onItemGet = () => audio.itemGet();
    eng.onItemUse = () => audio.beep(720, 0.09, "square");
    eng.onShield = () => audio.shield();
    eng.onExplode = () => audio.explode();
    eng.onPad = () => audio.pad();
    eng.onLand = (b) => audio.land(b);
    eng.onEliminate = () => audio.alarm();
    eng.onFinish = () => {
      audio.finishFanfare();
      const r = eng.getResults() as Results;
      setResults(r);
      const key = `${eng.trackId}:${eng.totalLaps}`;
      const prev = localStorage.getItem(BEST_KEY + key);
      if (!r.eliminated && (!prev || r.totalTime < Number(prev))) {
        localStorage.setItem(BEST_KEY + key, String(r.totalTime));
        setBest(r.totalTime); setIsNewRecord(true);
      } else setIsNewRecord(false);
      applyRewards(eng, r);
    };

    const resize = () => {
      const w = wrapRef.current?.clientWidth ?? 960;
      eng.resize(w, Math.round((w * 9) / 16));
    };
    resize();
    window.addEventListener("resize", resize);

    let last = performance.now(), acc = 0, frame = 0, raf = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now; acc += dt;
      let n = 0;
      while (acc >= STEP && n < 5) { eng.update(STEP); acc -= STEP; n++; }
      eng.render();
      const h = eng.getHud();
      const active = h.phase !== "menu" && !h.paused;
      audio.setEngine(Math.min(1, h.speedPct), eng.keys.up, active, h.boost > 0);
      audio.setDrift(active && h.phase === "racing" && h.drifting, Math.min(1, 0.35 + h.speedPct));
      if (frame++ % 3 === 0) setHud(h);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const km: Record<string, keyof Keys> = {
      ArrowLeft: "left", ArrowRight: "right", ArrowUp: "up", ArrowDown: "down",
      a: "left", d: "right", w: "up", s: "down", A: "left", D: "right", W: "up", S: "down",
    };
    const typing = (e: KeyboardEvent) => (e.target as HTMLElement)?.tagName === "INPUT";
    const tryStart = () => {
      if (eng.phase === "menu" || eng.phase === "finished") { audio.init(); setResults(null); eng.start(); }
    };
    const kd = (e: KeyboardEvent) => {
      if (typing(e)) return;
      if (e.key === "p" || e.key === "P" || e.key === "Escape") { eng.togglePause(); return; }
      if (eng.paused) return;
      const k = km[e.key];
      if (k) { eng.keys[k] = true; e.preventDefault(); }
      if (e.key === "Shift") { if (!e.repeat) eng.keys.driftTap = true; eng.keys.drift = true; }
      if (!e.repeat && (e.key === "ArrowUp" || e.key === "w" || e.key === "W")) eng.keys.accelTap = true;
      if ((e.key === "q" || e.key === "Q" || e.key === "e" || e.key === "E") && !e.repeat) eng.useItem();
      if (e.code === "Space" || e.key === "Enter") {
        if (e.code === "Space") e.preventDefault();
        if (eng.phase === "menu" || eng.phase === "finished") tryStart();
        else if (!e.repeat) eng.keys.nos = true;
      }
    };
    const ku = (e: KeyboardEvent) => {
      const k = km[e.key];
      if (k) eng.keys[k] = false;
      if (e.key === "Shift") eng.keys.drift = false;
    };
    const vis = () => { if (document.hidden) eng.pause(); };
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    document.addEventListener("visibilitychange", vis);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      document.removeEventListener("visibilitychange", vis);
      eng.dispose();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => { engRef.current?.setSkin(skin); localStorage.setItem(SKIN_KEY, JSON.stringify(skin)); }, [skin]);
  useEffect(() => { engRef.current?.setMode(mode); }, [mode]);
  useEffect(() => { engRef.current?.setLaps(laps); }, [laps]);
  useEffect(() => { engRef.current?.setRoom(codeToSeed(party.code), party.members, party.code); }, [party]);
  useEffect(() => { const e = engRef.current; if (e) e.tuning = tuningBonus(save.tuning); }, [save.tuning]);
  useEffect(() => {
    const e = engRef.current;
    if (e) e.ghostData = mode === "time" && useGhost ? save.ghosts[trackId] ?? null : null;
  }, [mode, useGhost, trackId, save.ghosts]);

  const startGame = useCallback((licenseId?: string) => {
    const e = engRef.current;
    if (!e) return;
    audioRef.current.init();
    setResults(null);
    setEarned({ coins: 0, unlocked: [] });
    if (licenseId) {
      const t = LICENSES.find((l) => l.id === licenseId);
      if (t) {
        setActiveLicense(licenseId); licRef.current = licenseId;
        setMode("license"); e.setMode("license");
        e.licenseGoal = t.goal;
        e.setLaps(3);
        const tid = TRACKS.some((x) => x.id === t.trackId) ? t.trackId : "coast";
        if (tid !== e.trackId) { e.setTrack(tid); setTrackId(tid); }
      }
    } else {
      setActiveLicense(null); licRef.current = null;
      e.licenseGoal = null;
      e.setLaps(laps);
      if (mode === "license") { setMode("race"); e.setMode("race"); }
    }
    e.tuning = tuningBonus(saveRef.current.tuning);
    e.ghostData = mode === "time" && useGhost ? saveRef.current.ghosts[e.trackId] ?? null : null;
    e.start();
  }, [mode, useGhost, laps]);

  const buyPart = useCallback((id: PartId) => {
    setSave((prev) => {
      const lv = prev.tuning[id] ?? 0;
      const part = PARTS.find((p) => p.id === id);
      if (!part || lv >= 5 || prev.coins < part.costs[lv]) return prev;
      const next = { ...prev, coins: prev.coins - part.costs[lv], tuning: { ...prev.tuning, [id]: lv + 1 } };
      saveSave(next);
      const e = engRef.current;
      if (e) e.tuning = tuningBonus(next.tuning);
      audioRef.current.itemGet();
      return next;
    });
  }, []);

  const selectTrack = useCallback((id: string) => { setTrackId(id); engRef.current?.setTrack(id); }, []);
  const press = (k: keyof Keys, v: boolean) => (e: React.PointerEvent) => { e.preventDefault(); if (engRef.current) engRef.current.keys[k] = v; };
  const toggleMute = () => { const m = !muted; setMuted(m); audioRef.current.setMuted(m); };

  const phase = hud.phase;
  const inRace = phase !== "menu";
  const track = TRACKS.find((t) => t.id === trackId) ?? TRACKS[0];
  const top5 = useMemo(() => hud.standings.slice(0, 5), [hud.standings]);
  const hpPct = hud.hp / hud.maxHp;

  return (
    <div className="relative mx-auto w-full max-w-5xl select-none" ref={wrapRef}>
      <div className="relative aspect-video w-full overflow-hidden rounded-2xl border border-white/10 bg-black shadow-[0_0_80px_rgba(255,80,120,0.25)]">
        <canvas ref={canvasRef} className="block h-full w-full" />
        {!ready && <div className="absolute inset-0 flex items-center justify-center text-sm text-white/60">正在加载 3D 引擎…</div>}

        {/* ================= HUD ================= */}
        {inRace && phase !== "intro" && (
          <>
            {/* 圈数 / 时间 */}
            <div className="absolute top-2 left-2 rounded-xl bg-black/45 px-3 py-2 font-mono text-white backdrop-blur-sm sm:top-4 sm:left-4">
              <div className="flex items-baseline gap-1.5">
                <span className="text-[9px] tracking-widest text-white/60 uppercase">Lap</span>
                <span className="text-lg font-bold sm:text-2xl">{hud.lap}<span className="text-xs text-white/50">/{hud.totalLaps}</span></span>
              </div>
              <div className="text-[10px] text-white/70 sm:text-sm">本圈 <span className="text-white">{fmt(hud.lapTime)}</span></div>
              <div className="text-[9px] text-white/50">最快 <span className="text-amber-300">{fmt(hud.bestLap)}</span></div>
            </div>

            {/* 血量 */}
            <div className="absolute top-[4.6rem] left-2 w-36 rounded-xl bg-black/45 px-2.5 py-1.5 backdrop-blur-sm sm:top-[6.6rem] sm:left-4 sm:w-44">
              <div className="mb-1 flex items-center justify-between text-[9px]">
                <span className="flex items-center gap-1 tracking-widest text-white/60 uppercase"><Heart className="h-3 w-3 text-rose-400" />车况</span>
                <span className={cn("font-mono font-bold", hpPct > 0.5 ? "text-lime-300" : hpPct > 0.25 ? "text-amber-300" : "animate-pulse text-red-400")}>{Math.round(hud.hp)}</span>
              </div>
              <div className={cn("h-2 overflow-hidden rounded-full bg-white/12", hud.hpFlash > 0 && "ring-2 ring-red-500")}>
                <div
                  className={cn("h-full rounded-full transition-[width] duration-200", hpPct > 0.5 ? "bg-gradient-to-r from-lime-400 to-emerald-400" : hpPct > 0.25 ? "bg-gradient-to-r from-amber-400 to-orange-400" : "bg-gradient-to-r from-red-500 to-rose-500")}
                  style={{ width: `${Math.max(0, hpPct * 100)}%` }}
                />
              </div>
              {hud.offroad && <div className="mt-0.5 text-[8px] text-amber-300">⚠ 缓冲区：撞障碍物扣血</div>}
              {!hud.offroad && hpPct < 1 && <div className="mt-0.5 text-[8px] text-lime-300">🔧 赛道上自动修复中</div>}
            </div>

            {/* 名次 + 小地图 */}
            <div className="absolute top-2 left-1/2 flex -translate-x-1/2 flex-col items-center gap-1 sm:top-4">
              {hud.mode !== "time" && hud.mode !== "license" && (
                <div className="rounded-xl bg-black/50 px-3 py-0.5 backdrop-blur-sm">
                  <span className="text-xl leading-none font-black text-amber-300 italic sm:text-3xl">P{hud.position}</span>
                  <span className="text-[10px] text-white/50">/{hud.totalRacers}</span>
                </div>
              )}
              <div className="rounded-xl bg-black/45 p-1 backdrop-blur-sm">
                <div className="relative h-14 w-14 sm:h-24 sm:w-24">
                  <svg viewBox="0 0 100 100" className="h-full w-full">
                    {hud.mapPath.length > 2 && (
                      <polyline points={hud.mapPath.map((p) => `${(p.x * 100).toFixed(1)},${(p.y * 100).toFixed(1)}`).join(" ")} fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth={4} strokeLinejoin="round" strokeLinecap="round" />
                    )}
                    {hud.mapRivals.map((r, i) => <circle key={i} cx={r.x * 100} cy={r.y * 100} r={2.2} fill={r.teammate ? "#38bdf8" : "#fb7185"} />)}
                    <circle cx={hud.mapPlayer.x * 100} cy={hud.mapPlayer.y * 100} r={3} fill={skin.paintA} stroke="#fff" strokeWidth={1} />
                  </svg>
                </div>
              </div>
              {/* 道具槽 */}
              {hud.itemsEnabled && (
                <button
                  onClick={() => engRef.current?.useItem()}
                  className={cn("flex h-11 w-11 items-center justify-center rounded-xl border-2 text-2xl backdrop-blur-sm transition sm:h-14 sm:w-14",
                    hud.item ? "animate-pulse border-amber-300 bg-amber-400/25 shadow-[0_0_18px_rgba(252,211,77,0.6)]" : "border-white/20 bg-black/40")}
                >
                  {hud.itemRolling ? <span className="animate-spin">🎁</span> : hud.item ? ITEMS[hud.item].emoji : <span className="text-xs text-white/25">空</span>}
                </button>
              )}
              {/* 淘汰倒计时 */}
              {hud.mode === "elim" && phase === "racing" && (
                <div className={cn("rounded-lg px-2.5 py-0.5 text-center backdrop-blur-sm", hud.elimWarn ? "animate-pulse bg-red-600/90" : "bg-black/55")}>
                  <div className="text-[8px] tracking-widest text-white/70 uppercase">淘汰</div>
                  <div className={cn("font-mono text-base leading-none font-black", hud.elimWarn ? "text-white" : "text-red-300")}>{hud.elimTimer.toFixed(1)}</div>
                </div>
              )}
              {/* 驾照进度 */}
              {hud.mode === "license" && (
                <div className="w-36 rounded-lg bg-black/60 px-2 py-1 backdrop-blur-sm sm:w-52">
                  <div className="mb-0.5 text-center text-[9px] font-bold text-cyan-200">{LICENSES.find((l) => l.id === activeLicense)?.brief ?? "驾照考试"}</div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-white/12">
                    <div className="h-full bg-gradient-to-r from-cyan-400 to-lime-300" style={{ width: `${Math.round(hud.licenseProgress * 100)}%` }} />
                  </div>
                </div>
              )}
            </div>

            {/* 排行 + 暂停 */}
            <div className="absolute top-2 right-2 flex flex-col items-end gap-1 sm:top-4 sm:right-4">
              <button onClick={() => engRef.current?.togglePause()} className="rounded-xl bg-black/45 p-2 text-white backdrop-blur-sm transition hover:bg-black/65">
                {hud.paused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
              </button>
              {hud.mode !== "time" && hud.mode !== "license" && !hud.paused && (
                <div className="w-28 rounded-xl bg-black/45 px-2 py-1 backdrop-blur-sm sm:w-40">
                  {top5.map((s, i) => (
                    <div key={s.name + i} className={cn("flex items-center gap-1 text-[9px] leading-tight sm:text-[11px]", s.isPlayer ? "font-black text-amber-300" : "text-white/70")}>
                      <span className="w-3 text-right opacity-60">{i + 1}</span>
                      <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: s.color }} />
                      <span className="truncate">{s.name}</span>
                      {hud.mode === "team" && s.isTeammate && <span className="text-cyan-300">◆</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 连喷 */}
            {hud.combo > 1 && !hud.paused && (
              <div className="absolute top-[45%] right-3 text-right sm:right-8">
                <div className="font-mono text-2xl leading-none font-black text-amber-300 italic drop-shadow-[0_0_12px_rgba(252,211,77,0.8)] sm:text-5xl">x{hud.combo}</div>
                <div className="text-[8px] tracking-widest text-amber-200/70 uppercase">Combo</div>
              </div>
            )}

            {/* 双喷判定 / LINK */}
            {hud.dblWindow > 0 && !hud.paused && (
              <div className="absolute bottom-[24%] left-1/2 w-48 -translate-x-1/2 sm:w-72">
                <div className="mb-1 text-center text-[9px] font-bold tracking-widest text-cyan-200 uppercase">再点 Shift → 双喷</div>
                <div className="relative h-3 overflow-hidden rounded-full border border-white/30 bg-black/60">
                  <div className="absolute inset-y-0 bg-gradient-to-r from-amber-300/70 to-lime-300/70" style={{ left: `${hud.dblPerfect[0] * 100}%`, width: `${(hud.dblPerfect[1] - hud.dblPerfect[0]) * 100}%` }} />
                  <div className="absolute inset-y-0 w-1 bg-white shadow-[0_0_8px_#fff]" style={{ left: `${(1 - hud.dblWindow / 0.62) * 100}%` }} />
                </div>
              </div>
            )}
            {hud.linkReady && !hud.paused && (
              <div className="absolute bottom-[24%] left-1/2 -translate-x-1/2 animate-pulse rounded-md bg-cyan-400/90 px-3 py-1 text-[10px] font-black text-black">⚡ 按氮气 → LINK</div>
            )}

            {/* 氮气 */}
            <div className="absolute bottom-2 left-2 w-36 rounded-xl bg-black/45 px-3 py-2 backdrop-blur-sm sm:bottom-4 sm:left-4 sm:w-48">
              <div className="mb-1 flex items-center justify-between">
                <span className="flex items-center gap-1 text-[9px] tracking-widest text-cyan-300/90 uppercase"><Zap className="h-3 w-3" />Nitro</span>
                <div className="flex gap-1">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Zap key={i} className={cn("h-3 w-3 sm:h-4 sm:w-4", i < hud.cans ? "fill-cyan-300 text-cyan-300 drop-shadow-[0_0_6px_#67e8f9]" : "text-white/15")} />
                  ))}
                </div>
              </div>
              <div className={cn("h-2 overflow-hidden rounded-full bg-white/10", hud.boost > 0 && "shadow-[0_0_12px_#67e8f9]")}>
                <div className={cn("h-full rounded-full", hud.boost > 0 ? "bg-gradient-to-r from-cyan-200 to-blue-500" : "bg-gradient-to-r from-cyan-500/80 to-fuchsia-500/80")} style={{ width: `${Math.round(hud.charge)}%` }} />
              </div>
              <div className={cn("mt-0.5 text-[8px]", hud.linkReady ? "font-bold text-cyan-300" : "text-white/40")}>
                {hud.linkReady ? "LINK 窗口！" : hud.wcArmed ? "WC 已装填" : hud.cans >= 3 ? "集气已满" : "Shift 漂移集气"}
              </div>
            </div>

            {/* 速度 */}
            <div className="absolute right-2 bottom-2 rounded-xl bg-black/45 px-3 py-2 font-mono text-white backdrop-blur-sm sm:right-4 sm:bottom-4">
              <div className="relative h-12 w-12 sm:h-20 sm:w-20">
                <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
                  <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="10" />
                  <circle cx="50" cy="50" r="42" fill="none"
                    stroke={hud.boost > 0 ? "#67e8f9" : hud.speedPct > 0.85 ? "#ff3b6b" : hud.speedPct > 0.5 ? "#ffb347" : "#22d3ee"}
                    strokeWidth="10" strokeLinecap="round" strokeDasharray={`${Math.min(1, hud.speedPct) * 264} 264`}
                    style={hud.boost > 0 ? { filter: "drop-shadow(0 0 6px #67e8f9)" } : undefined} />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className={cn("text-xs leading-none font-bold sm:text-xl", hud.boost > 0 && "text-cyan-300")}>{hud.speedKmh}</span>
                  <span className="text-[7px] text-white/50">km/h</span>
                </div>
              </div>
            </div>

            {/* 状态提示 */}
            {hud.drifting && !hud.paused && (
              <div className={cn("absolute bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-md px-2.5 py-1 text-[10px] font-bold text-white", hud.wcArmed ? "bg-cyan-500/90" : "bg-fuchsia-500/85")}>
                <Wind className="h-3 w-3 animate-pulse" />{hud.wcArmed ? "WC装填" : "漂移"} {hud.driftTime.toFixed(1)}s
              </div>
            )}
            {hud.airborne && !hud.paused && (
              <div className="absolute top-[36%] left-1/2 -translate-x-1/2 text-center">
                <div className="text-xl font-black text-white italic drop-shadow-[0_0_12px_#fff] sm:text-3xl">腾空！</div>
                <div className="text-[10px] font-bold text-cyan-200">落地按住油门 → 落地喷</div>
              </div>
            )}
            {(hud.shieldT > 0 || hud.ghostT > 0) && !hud.paused && (
              <div className="absolute bottom-[16%] left-1/2 flex -translate-x-1/2 gap-1.5">
                {hud.shieldT > 0 && <span className="rounded-md bg-sky-500/85 px-2 py-0.5 text-[10px] font-black text-white">🛡️ {hud.shieldT.toFixed(1)}</span>}
                {hud.ghostT > 0 && <span className="rounded-md bg-slate-200/85 px-2 py-0.5 text-[10px] font-black text-black">👻 {hud.ghostT.toFixed(1)}</span>}
              </div>
            )}
            {hud.itemFlash && !hud.paused && (
              <div className="absolute top-[24%] left-1/2 -translate-x-1/2 rounded-lg bg-black/70 px-3 py-1 text-xs font-black text-amber-200 backdrop-blur-sm sm:text-base">{hud.itemFlash}</div>
            )}
            {hud.boostLabel && !hud.paused && (
              <div key={hud.boostSeq} className="absolute top-[30%] left-1/2 -translate-x-1/2">
                <div className="animate-[boostpop_0.9s_ease-out_forwards] bg-gradient-to-b from-cyan-200 to-blue-400 bg-clip-text text-2xl font-black text-transparent italic drop-shadow-[0_0_18px_#67e8f9] sm:text-5xl">{hud.boostLabel}</div>
              </div>
            )}
          </>
        )}

        {/* 入场动画 */}
        {phase === "intro" && (
          <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-4 sm:p-8">
            <div className="animate-[boostpop_1s_ease-out] text-center">
              <div className="text-[10px] tracking-[0.6em] text-white/60 uppercase">{track.theme.nameEn}</div>
              <div className="bg-gradient-to-b from-white to-white/50 bg-clip-text text-3xl font-black text-transparent italic drop-shadow sm:text-6xl">{track.theme.name}</div>
              <div className="mt-1 text-xs font-bold text-amber-300 sm:text-base">{laps === 1 ? "短程冲刺 · 1 圈" : "长程耐力 · 3 圈"} · {MODES.find((m) => m.id === mode)?.name ?? "驾照考试"}</div>
            </div>
            <div className="flex items-end justify-between">
              <div className="rounded-xl bg-black/50 px-3 py-2 backdrop-blur-sm">
                <div className="text-[9px] tracking-widest text-white/50 uppercase">Driver</div>
                <div className="text-base font-black text-white sm:text-xl">{skin.model.name}</div>
                <div className="text-[10px] text-white/50">{skin.model.tier} 级 · {skin.model.desc}</div>
              </div>
              <div className="h-1 flex-1 mx-4 overflow-hidden rounded-full bg-white/15">
                <div className="h-full bg-gradient-to-r from-pink-500 to-amber-300 transition-[width] duration-100" style={{ width: `${Math.round((1 - hud.introT / 3.6) * 100)}%` }} />
              </div>
            </div>
          </div>
        )}

        {/* 倒计时 */}
        {phase === "countdown" && !hud.paused && (
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
            <div key={Math.ceil(hud.countdown)} className="animate-[ping_1s_ease-out_1] text-[5rem] leading-none font-black text-white drop-shadow-[0_0_30px_#fff] sm:text-[11rem]">{Math.ceil(hud.countdown)}</div>
            <div className="mt-2 rounded-full bg-black/50 px-3 py-1 text-[10px] text-cyan-300 backdrop-blur-sm sm:text-sm">GO 瞬间按住油门 = 起步喷</div>
          </div>
        )}
        {phase === "racing" && hud.goTimer > 0 && !hud.paused && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="bg-gradient-to-r from-lime-300 to-cyan-300 bg-clip-text text-[4rem] leading-none font-black text-transparent drop-shadow-[0_0_30px_#7f7] sm:text-[10rem]">GO!</div>
          </div>
        )}

        {/* 暂停 */}
        {hud.paused && inRace && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/60 px-4 backdrop-blur-[2px]">
            <div className="w-full max-w-xs rounded-2xl border border-white/15 bg-zinc-900/90 p-5 text-center text-white shadow-2xl">
              <div className="text-xs tracking-[0.4em] text-white/50 uppercase">Paused</div>
              <h2 className="mt-1 text-2xl font-black">已暂停</h2>
              <p className="mt-1 text-xs text-white/50">{track.theme.name} · 第 {hud.lap}/{hud.totalLaps} 圈{hud.mode !== "time" && ` · P${hud.position}`}</p>
              <div className="mt-4 flex flex-col gap-2">
                <button onClick={() => engRef.current?.togglePause()} className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-pink-500 to-orange-400 py-2.5 font-bold transition hover:brightness-110"><Play className="h-4 w-4 fill-current" />继续</button>
                <button onClick={() => startGame(activeLicense ?? undefined)} className="flex items-center justify-center gap-2 rounded-xl border border-white/20 py-2.5 font-semibold text-white/85 transition hover:bg-white/10"><RotateCcw className="h-4 w-4" />重新开始</button>
                <button onClick={() => { setResults(null); engRef.current?.backToMenu(); }} className="flex items-center justify-center gap-2 rounded-xl border border-white/20 py-2.5 font-semibold text-white/85 transition hover:bg-white/10"><Home className="h-4 w-4" />回车库</button>
              </div>
            </div>
          </div>
        )}

        {/* ================= 主菜单 ================= */}
        {phase === "menu" && (
          <div className="absolute inset-0 overflow-y-auto bg-gradient-to-b from-black/45 via-black/60 to-black/80 px-3 py-2.5 sm:px-5 sm:py-3">
            <div className="flex items-center justify-between">
              <h1 className="bg-gradient-to-b from-yellow-200 via-orange-400 to-pink-500 bg-clip-text text-xl font-black tracking-tight text-transparent italic sm:text-3xl">落日狂飙 3D</h1>
              <div className="flex items-center gap-1">
                <span className="mr-1 flex items-center gap-1 rounded-full bg-amber-400/15 px-2 py-0.5 text-[10px] font-bold text-amber-300"><Coins className="h-3 w-3" />{save.coins}</span>
                {(["track", "garage", "tune", "license", "party", "stats"] as const).map((t) => (
                  <button key={t} onClick={() => setTab(t)} className={cn("rounded-lg px-1.5 py-1 text-[9px] font-bold transition sm:px-2 sm:text-[11px]", tab === t ? "bg-white text-black" : "bg-white/10 text-white/70 hover:bg-white/20")}>
                    {t === "track" ? "赛道" : t === "garage" ? "车库" : t === "tune" ? "改装" : t === "license" ? "驾照" : t === "party" ? "组队" : "生涯"}
                  </button>
                ))}
              </div>
            </div>

            {/* 模式 + 赛程 */}
            <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
              {MODES.map((m) => {
                const Icon = m.icon;
                return (
                  <button key={m.id} onClick={() => { setMode(m.id); if (m.id === "team") setTab("party"); }}
                    className={cn("flex items-center gap-1 rounded-lg border px-2 py-1 transition", mode === m.id ? "border-pink-400 bg-pink-500/25" : "border-white/12 bg-white/5 hover:bg-white/10")}>
                    <Icon className={cn("h-3 w-3", mode === m.id ? "text-pink-300" : "text-white/50")} />
                    <span className="text-[10px] font-bold text-white">{m.name}</span>
                  </button>
                );
              })}
              <div className="ml-auto flex gap-1 rounded-lg border border-white/15 bg-black/40 p-0.5">
                {[1, 3].map((n) => (
                  <button key={n} onClick={() => setLaps(n)} className={cn("rounded-md px-2 py-1 text-[10px] font-bold transition", laps === n ? "bg-amber-400 text-black" : "text-white/60 hover:bg-white/10")}>
                    {n === 1 ? "短程 1 圈" : "长程 3 圈"}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-2">
              {tab === "track" && (
                <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-5">
                  {TRACKS.map((t) => (
                    <button key={t.id} onClick={() => selectTrack(t.id)}
                      className={cn("group relative h-16 overflow-hidden rounded-xl border text-left transition sm:h-24", trackId === t.id ? "border-white/80 ring-2 ring-white/70" : "border-white/15 opacity-80 hover:opacity-100")}
                      style={{ backgroundImage: `linear-gradient(135deg, ${t.theme.preview[0]}, ${t.theme.preview[1]})` }}>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" />
                      <div className="absolute right-1 bottom-1 left-1.5">
                        <div className="text-[10px] leading-tight font-bold text-white sm:text-xs">{t.theme.name}</div>
                        <div className="hidden text-[8px] leading-tight text-white/60 sm:block">{t.theme.desc}</div>
                        <div className="flex gap-0.5">
                          {Array.from({ length: 3 }).map((_, i) => <Star key={i} className={cn("h-1.5 w-1.5", i < t.theme.difficulty ? "fill-amber-300 text-amber-300" : "text-white/25")} />)}
                        </div>
                      </div>
                      {trackId === t.id && <div className="absolute top-0.5 right-0.5 rounded-full bg-white px-1 text-[7px] font-black text-black">已选</div>}
                    </button>
                  ))}
                </div>
              )}
              {tab === "garage" && <Garage3D skin={skin} onChange={setSkin} />}
              {tab === "tune" && <TuningPanel save={save} onBuy={buyPart} />}
              {tab === "license" && <LicensePanel save={save} onStart={(id) => startGame(id)} />}
              {tab === "party" && (
                <div className="grid gap-2 sm:grid-cols-2">
                  <PartyPanel party={party} onChange={setParty} />
                  <RoomBoard save={save} room={party.code} track={trackId} />
                </div>
              )}
              {tab === "stats" && <div className="space-y-2"><StatsPanel save={save} /><ItemCodex /></div>}
            </div>

            {mode === "time" && (
              <div className="mt-1.5 flex justify-center">
                <button onClick={() => setUseGhost((v) => !v)} className={cn("flex items-center gap-1.5 rounded-full border px-3 py-0.5 text-[10px] font-bold transition", useGhost ? "border-cyan-400/60 bg-cyan-400/20 text-cyan-200" : "border-white/20 bg-white/5 text-white/50")}>
                  <Ghost className="h-3 w-3" />幽灵车 {useGhost ? "开" : "关"}{save.ghosts[trackId] ? " · 有记录" : " · 暂无"}
                </button>
              </div>
            )}

            <div className="mt-2 flex flex-col items-center gap-1">
              <button onClick={() => startGame()} className="flex items-center gap-2 rounded-full bg-gradient-to-r from-pink-500 to-orange-400 px-8 py-2 text-base font-bold text-white shadow-lg shadow-pink-500/40 transition hover:scale-105 active:scale-95">
                <Play className="h-5 w-5 fill-current" />
                {mode === "team" ? `组队出发（${party.members.length + 1} 人）` : mode === "time" ? "开始计时" : mode === "item" ? "道具大战" : mode === "elim" ? "生存淘汰" : "开始竞速"}
              </button>
              <div className="flex flex-wrap items-center justify-center gap-x-2.5 text-[9px] text-white/55 sm:text-[11px]">
                <span><kbd className="rounded bg-white/15 px-1 font-mono">WASD</kbd> 驾驶</span>
                <span><kbd className="rounded bg-white/15 px-1 font-mono text-fuchsia-300">Shift</kbd> 漂移</span>
                <span><kbd className="rounded bg-white/15 px-1 font-mono text-cyan-300">空格</kbd> 氮气</span>
                <span><kbd className="rounded bg-white/15 px-1 font-mono text-amber-300">Q</kbd> 道具</span>
                <span><kbd className="rounded bg-white/15 px-1 font-mono">P</kbd> 暂停</span>
                <span className="flex items-center gap-1 text-amber-200"><MapIcon className="h-2.5 w-2.5" />{track.theme.name}</span>
                {best !== null && <span className="flex items-center gap-1 text-amber-300"><Trophy className="h-2.5 w-2.5" />{fmt(best)}</span>}
              </div>
            </div>
          </div>
        )}

        {/* ================= 结算 ================= */}
        {phase === "finished" && results && !hud.paused && (
          <div className="absolute inset-0 flex items-center justify-center overflow-y-auto bg-black/70 px-3 py-3">
            <div className="w-full max-w-md rounded-2xl border border-white/15 bg-zinc-900/92 p-4 text-white shadow-2xl backdrop-blur">
              <div className="text-center">
                <div className="text-[10px] tracking-[0.4em] text-white/50 uppercase">Race Complete</div>
                {results.eliminated ? <h2 className="flex items-center justify-center gap-2 text-2xl font-black text-red-400"><Skull className="h-6 w-6" />被淘汰！</h2>
                  : results.mode === "license" ? <h2 className={cn("flex items-center justify-center gap-2 text-2xl font-black", results.licensePassed ? "text-lime-300" : "text-white/70")}><Award className="h-6 w-6" />{results.licensePassed ? "考试通过！" : "未通过"}</h2>
                  : results.mode === "time" ? <h2 className="flex items-center justify-center gap-2 text-2xl font-black text-amber-300"><Flag className="h-6 w-6" />完赛！</h2>
                  : <h2 className={cn("text-3xl font-black italic", results.position === 1 ? "text-amber-300" : results.position <= 3 ? "text-cyan-300" : "text-white/80")}>P{results.position}<span className="text-sm text-white/40"> / {results.totalRacers}</span>{results.position === 1 && " 🏆"}</h2>}
                {isNewRecord && <div className="flex animate-pulse items-center justify-center gap-1 text-xs font-bold text-pink-400"><Sparkles className="h-3.5 w-3.5" />新纪录！</div>}
                {results.mode === "team" && (
                  <div className="mt-1 flex items-center justify-center gap-2 text-sm font-bold">
                    <span className="text-cyan-300">我方 {results.teamScore}</span><span className="text-white/30">VS</span><span className="text-pink-300">对手 {results.rivalScore}</span>
                    <span className={cn("rounded px-1.5 text-[10px]", results.teamScore >= results.rivalScore ? "bg-lime-400/20 text-lime-300" : "bg-red-400/20 text-red-300")}>{results.teamScore >= results.rivalScore ? "胜利" : "失利"}</span>
                  </div>
                )}
              </div>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                <div className="space-y-0.5 font-mono text-xs">
                  {results.lapTimes.map((t, i) => (
                    <div key={i} className="flex justify-between text-white/75"><span>第 {i + 1} 圈</span><span className={cn(t === results.bestLapTime && "text-amber-300")}>{fmt(t)}</span></div>
                  ))}
                  <div className="my-1 border-t border-white/10" />
                  <div className="flex justify-between font-bold"><span>总时间</span><span>{fmt(results.totalTime)}</span></div>
                  <div className="flex justify-between text-white/65"><span>最高时速</span><span className="text-pink-300">{results.maxSpeedKmh}</span></div>
                  <div className="flex justify-between text-white/65"><span>最高连喷</span><span className="text-amber-300">x{results.bestCombo}</span></div>
                  <div className="flex justify-between text-white/65"><span>剩余车况</span><span className={results.hp > 60 ? "text-lime-300" : "text-amber-300"}>{results.hp}</span></div>
                </div>
                {results.mode !== "time" && results.mode !== "license" && (
                  <div className="rounded-lg border border-white/10 bg-black/30 p-2">
                    <div className="mb-1 text-[9px] tracking-widest text-white/40 uppercase">最终排名</div>
                    {results.standings.map((s, i) => (
                      <div key={s.name + i} className={cn("flex items-center gap-1.5 text-[10px]", s.isPlayer ? "font-black text-amber-300" : "text-white/65")}>
                        <span className="w-3 text-right opacity-60">{i + 1}</span>
                        <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: s.color }} />
                        <span className="truncate">{s.name}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              {earned.coins > 0 && (
                <div className="mt-2 rounded-lg border border-amber-400/30 bg-amber-400/10 p-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1 font-bold text-amber-300"><Coins className="h-3.5 w-3.5" />获得金币</span>
                    <span className="font-mono text-base font-black text-amber-300">+{earned.coins}</span>
                  </div>
                  {earned.unlocked.length > 0 && (
                    <div className="mt-1 flex flex-wrap gap-1">
                      {earned.unlocked.map((u) => <span key={u} className="rounded-full bg-lime-400/20 px-2 py-0.5 text-[9px] font-bold text-lime-300">🎉 {u}</span>)}
                    </div>
                  )}
                </div>
              )}
              <div className="mt-3 flex gap-2">
                <button onClick={() => startGame(activeLicense ?? undefined)} className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-pink-500 to-orange-400 py-2.5 font-bold transition hover:brightness-110"><RotateCcw className="h-4 w-4" />再来一局</button>
                <button onClick={() => { setResults(null); setEarned({ coins: 0, unlocked: [] }); engRef.current?.backToMenu(); }} className="rounded-xl border border-white/20 px-4 py-2.5 font-semibold text-white/80 transition hover:bg-white/10">车库</button>
              </div>
            </div>
          </div>
        )}

        <button onClick={toggleMute} className={cn("absolute z-20 rounded-full bg-black/45 p-2 text-white/80 backdrop-blur-sm transition hover:bg-black/65", inRace ? "bottom-[4.5rem] left-2 sm:bottom-24 sm:left-4" : "bottom-2 right-2 sm:bottom-4 sm:right-4")}>
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </button>
      </div>

      {/* 触屏 */}
      <div className="mt-3 flex flex-col gap-2 md:hidden">
        <div className="grid grid-cols-2 gap-3">
          <div className="flex gap-2">
            <TouchBtn label={<ChevronLeft className="h-7 w-7" />} onDown={press("left", true)} onUp={press("left", false)} />
            <TouchBtn label={<ChevronRight className="h-7 w-7" />} onDown={press("right", true)} onUp={press("right", false)} />
          </div>
          <div className="flex justify-end gap-2">
            <TouchBtn label="刹车" onDown={press("down", true)} onUp={press("down", false)} className="border-red-400/40 bg-red-500/30" />
            <TouchBtn label="油门" onDown={(e) => { e.preventDefault(); const g = engRef.current; if (g) { g.keys.accelTap = true; g.keys.up = true; } }} onUp={press("up", false)} className="border-emerald-400/40 bg-emerald-500/30" />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <TouchBtn label={<span className="flex items-center gap-1"><Wind className="h-4 w-4" />漂移</span>} onDown={(e) => { e.preventDefault(); const g = engRef.current; if (g) { g.keys.driftTap = true; g.keys.drift = true; } }} onUp={press("drift", false)} className="h-12 border-fuchsia-400/40 bg-fuchsia-500/30" />
          <TouchBtn label={<span className="flex items-center gap-1"><Flame className="h-4 w-4" />氮气{hud.cans}</span>} onDown={(e) => { e.preventDefault(); engRef.current?.useNitro(); }} onUp={() => {}} className="h-12 border-cyan-400/40 bg-cyan-500/30" />
          <TouchBtn label={<span className="text-lg">{hud.item ? ITEMS[hud.item].emoji : "🎁"}</span>} onDown={(e) => { e.preventDefault(); engRef.current?.useItem(); }} onUp={() => {}} className="h-12 border-amber-400/40 bg-amber-500/30" />
        </div>
      </div>
    </div>
  );
}


function TouchBtn({ label, onDown, onUp, className }: { label: React.ReactNode; onDown: (e: React.PointerEvent) => void; onUp: (e: React.PointerEvent) => void; className?: string }) {
  return (
    <button onPointerDown={onDown} onPointerUp={onUp} onPointerLeave={onUp} onPointerCancel={onUp} onContextMenu={(e) => e.preventDefault()}
      className={cn("flex h-14 flex-1 touch-none items-center justify-center rounded-2xl border border-white/20 bg-white/10 text-base font-bold text-white active:scale-95 active:bg-white/25", className)}>
      {label}
    </button>
  );
}
