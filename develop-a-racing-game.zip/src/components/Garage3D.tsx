import { useEffect, useRef } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { CAR_MODELS, LIVERIES, PAINTS, buildCar, type CarSkin3D, type LiveryId } from "../game3d/carModels";
import { cn } from "../utils/cn";
import { Palette, Shapes, Sparkles } from "lucide-react";

const TIER_COLOR: Record<string, string> = {
  B: "from-slate-400 to-slate-600",
  A: "from-sky-400 to-blue-600",
  S: "from-fuchsia-400 to-purple-600",
  T: "from-amber-300 to-orange-500",
};

export function CarPreview3D({ skin, className }: { skin: CarSkin3D; className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const skinRef = useRef(skin);
  skinRef.current = skin;

  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ canvas: cv, antialias: true, alpha: true });
    } catch {
      return;
    }
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

    const cam = new THREE.PerspectiveCamera(38, 2, 0.1, 100);
    cam.position.set(5.4, 2.5, 5.8);
    cam.lookAt(0, 0.75, 0);

    const key = new THREE.DirectionalLight(0xffffff, 3);
    key.position.set(6, 9, 5);
    scene.add(key);
    const rim = new THREE.DirectionalLight(0xff5fa2, 2.2);
    rim.position.set(-6, 3, -5);
    scene.add(rim);
    const fill = new THREE.DirectionalLight(0x66ccff, 1.6);
    fill.position.set(-4, 2, 6);
    scene.add(fill);
    scene.add(new THREE.HemisphereLight(0xbcd7ff, 0x1a1030, 1.2));

    // 展台
    const disc = new THREE.Mesh(
      new THREE.CylinderGeometry(3.4, 3.4, 0.14, 48),
      new THREE.MeshStandardMaterial({ color: "#181c28", metalness: 0.9, roughness: 0.22 }),
    );
    disc.position.y = -0.07;
    scene.add(disc);
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(3.45, 0.05, 8, 64),
      new THREE.MeshBasicMaterial({ color: "#67e8f9" }),
    );
    ring.rotation.x = Math.PI / 2;
    scene.add(ring);

    const holder = new THREE.Group();
    scene.add(holder);
    let rig = buildCar(skinRef.current);
    holder.add(rig.group);
    let lastKey = JSON.stringify(skinRef.current.model.id + skinRef.current.paintA + skinRef.current.livery);

    let raf = 0;
    const t0 = performance.now();
    const loop = (now: number) => {
      const t = (now - t0) / 1000;
      const k = skinRef.current.model.id + skinRef.current.paintA + skinRef.current.livery;
      if (k !== lastKey) {
        lastKey = k;
        holder.remove(rig.group);
        rig.group.traverse((o) => {
          const m = o as THREE.Mesh;
          if (m.geometry) m.geometry.dispose();
        });
        rig = buildCar(skinRef.current);
        holder.add(rig.group);
      }
      holder.rotation.y = t * 0.45;
      holder.position.y = Math.sin(t * 1.4) * 0.05;
      ring.material.color.set(skinRef.current.paintB);
      for (const w of rig.wheels) w.rotation.x -= 0.03;
      const w = cv.clientWidth || 420;
      const h = cv.clientHeight || 220;
      if (cv.width !== w * devicePixelRatio || cv.height !== h * devicePixelRatio) {
        renderer.setSize(w, h, false);
        cam.aspect = w / h;
        cam.updateProjectionMatrix();
      }
      renderer.render(scene, cam);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      pmrem.dispose();
      renderer.dispose();
    };
  }, []);

  return <canvas ref={ref} className={cn("h-full w-full", className)} />;
}

function StatBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="w-7 shrink-0 text-[9px] text-white/55">{label}</span>
      <div className="flex flex-1 gap-0.5">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className={cn("h-1.5 flex-1 rounded-full", i < value ? color : "bg-white/12")} />
        ))}
      </div>
    </div>
  );
}

export default function Garage3D({ skin, onChange }: { skin: CarSkin3D; onChange: (s: CarSkin3D) => void }) {
  return (
    <div className="grid gap-2 sm:grid-cols-[1.15fr_1fr]">
      <div className="relative h-40 overflow-hidden rounded-xl border border-white/15 bg-gradient-to-b from-slate-900/90 to-black/80 sm:h-48">
        <CarPreview3D skin={skin} />
        <div className="absolute top-2 left-3">
          <div className="flex items-center gap-1.5">
            <span className={cn("rounded px-1.5 text-[10px] font-black text-black", `bg-gradient-to-r ${TIER_COLOR[skin.model.tier]}`)}>{skin.model.tier}</span>
            <span className="text-sm font-black text-white drop-shadow">{skin.model.name}</span>
          </div>
          <div className="text-[9px] text-white/55">{skin.model.desc}</div>
        </div>
        <div className="absolute right-3 bottom-2 left-3 space-y-1">
          <StatBar label="极速" value={skin.model.stats.speed} color="bg-pink-400" />
          <StatBar label="加速" value={skin.model.stats.accel} color="bg-amber-400" />
          <StatBar label="抓地" value={skin.model.stats.grip} color="bg-cyan-400" />
        </div>
      </div>

      <div className="space-y-2">
        <div>
          <div className="mb-1 flex items-center gap-1 text-[10px] tracking-widest text-white/50 uppercase">
            <Shapes className="h-3 w-3" /> 车型
          </div>
          <div className="grid grid-cols-3 gap-1">
            {CAR_MODELS.map((m) => (
              <button
                key={m.id}
                onClick={() => onChange({ ...skin, model: m })}
                title={m.desc}
                className={cn(
                  "relative rounded-lg border px-1 py-1.5 text-[9px] leading-tight font-bold transition",
                  skin.model.id === m.id ? "border-white bg-white/20 text-white" : "border-white/15 bg-white/5 text-white/60 hover:bg-white/12",
                )}
              >
                <span className={cn("absolute top-0.5 right-0.5 rounded px-1 text-[7px] font-black text-black", `bg-gradient-to-r ${TIER_COLOR[m.tier]}`)}>{m.tier}</span>
                {m.name}
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="mb-1 flex items-center gap-1 text-[10px] tracking-widest text-white/50 uppercase">
            <Palette className="h-3 w-3" /> 车漆
          </div>
          <div className="flex flex-wrap gap-1">
            {PAINTS.map((p) => (
              <button
                key={p.name}
                title={p.name}
                onClick={() => onChange({ ...skin, paintA: p.a, paintB: p.b })}
                className={cn("h-6 w-6 rounded-md border-2 transition", skin.paintA === p.a ? "scale-110 border-white" : "border-white/20 hover:scale-105")}
                style={{ background: `linear-gradient(135deg, ${p.a}, ${p.b})` }}
              />
            ))}
          </div>
        </div>

        <div>
          <div className="mb-1 flex items-center gap-1 text-[10px] tracking-widest text-white/50 uppercase">
            <Sparkles className="h-3 w-3" /> 涂装
          </div>
          <div className="grid grid-cols-5 gap-1">
            {LIVERIES.map((l) => (
              <button
                key={l.id}
                onClick={() => onChange({ ...skin, livery: l.id as LiveryId })}
                className={cn(
                  "rounded-md border px-0.5 py-1 text-[9px] font-bold transition",
                  skin.livery === l.id ? "border-white bg-white/20 text-white" : "border-white/15 bg-white/5 text-white/60 hover:bg-white/12",
                )}
              >
                {l.name}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
