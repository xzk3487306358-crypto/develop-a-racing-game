import { ACHIEVEMENTS, LICENSES, MAX_PART_LEVEL, PARTS, licenseGrade, type SaveData } from "../game/progress";
import { ITEM_LIST } from "../game/items";
import { cn } from "../utils/cn";
import { Award, Check, Coins, Lock, Package, Trophy, Users } from "lucide-react";

// ------------------------------------------------------------------ 改装
export function TuningPanel({ save, onBuy }: { save: SaveData; onBuy: (id: (typeof PARTS)[number]["id"]) => void }) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-[10px] tracking-widest text-white/50 uppercase">
        <span>车辆改装</span>
        <span className="flex items-center gap-1 text-amber-300">
          <Coins className="h-3 w-3" />
          {save.coins}
        </span>
      </div>
      {PARTS.map((p) => {
        const lv = save.tuning[p.id] ?? 0;
        const maxed = lv >= MAX_PART_LEVEL;
        const cost = maxed ? 0 : p.costs[lv];
        const afford = save.coins >= cost;
        return (
          <div key={p.id} className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-2 py-1.5">
            <span className="text-base">{p.icon}</span>
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline gap-1.5">
                <span className="text-[11px] font-bold text-white">{p.name}</span>
                <span className="text-[9px] text-white/40">{p.desc}</span>
              </div>
              <div className="mt-0.5 flex gap-0.5">
                {Array.from({ length: MAX_PART_LEVEL }).map((_, i) => (
                  <div key={i} className={cn("h-1.5 flex-1 rounded-full", i < lv ? "bg-gradient-to-r from-cyan-400 to-fuchsia-400" : "bg-white/12")} />
                ))}
              </div>
            </div>
            <button
              disabled={maxed || !afford}
              onClick={() => onBuy(p.id)}
              className={cn(
                "shrink-0 rounded-md px-2 py-1 text-[10px] font-bold transition",
                maxed ? "bg-lime-400/20 text-lime-300" : afford ? "bg-amber-400 text-black hover:brightness-110 active:scale-95" : "bg-white/10 text-white/30",
              )}
            >
              {maxed ? "MAX" : `${cost}`}
            </button>
          </div>
        );
      })}
    </div>
  );
}

// ------------------------------------------------------------------ 驾照
export function LicensePanel({ save, onStart }: { save: SaveData; onStart: (id: string) => void }) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-[10px] tracking-widest text-white/50 uppercase">
        <span>驾照考试 · 学会组合喷</span>
        <span className="flex items-center gap-1 text-cyan-300">
          <Award className="h-3 w-3" />
          当前：{licenseGrade(save.licenses)}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-1.5">
        {LICENSES.map((l, i) => {
          const done = save.licenses.includes(l.id);
          const prevDone = i === 0 || save.licenses.includes(LICENSES[i - 1].id);
          const locked = !done && !prevDone;
          return (
            <button
              key={l.id}
              disabled={locked}
              onClick={() => onStart(l.id)}
              className={cn(
                "flex items-center gap-1.5 rounded-lg border px-2 py-1.5 text-left transition",
                done ? "border-lime-400/40 bg-lime-400/10" : locked ? "border-white/8 bg-white/3 opacity-45" : "border-white/15 bg-white/5 hover:bg-white/12",
              )}
            >
              <span className={cn("flex h-6 w-6 shrink-0 items-center justify-center rounded-md text-[10px] font-black", done ? "bg-lime-400 text-black" : "bg-white/15 text-white/70")}>
                {done ? <Check className="h-3.5 w-3.5" /> : locked ? <Lock className="h-3 w-3" /> : l.grade}
              </span>
              <div className="min-w-0">
                <div className="truncate text-[10px] font-bold text-white">{l.name}</div>
                <div className="truncate text-[9px] text-white/45">{l.brief}</div>
              </div>
              <span className="ml-auto shrink-0 text-[9px] font-bold text-amber-300">+{l.reward}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ 成就 / 统计
export function StatsPanel({ save }: { save: SaveData }) {
  const s = save.stats;
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      <div>
        <div className="mb-1 text-[10px] tracking-widest text-white/50 uppercase">生涯统计</div>
        <div className="space-y-0.5 rounded-lg border border-white/10 bg-white/5 p-2 font-mono text-[10px] text-white/70">
          <Row k="总场次" v={s.races} />
          <Row k="冠军数" v={s.wins} c="text-amber-300" />
          <Row k="完美双喷" v={s.perfects} c="text-lime-300" />
          <Row k="道具使用" v={s.items} c="text-cyan-300" />
          <Row k="碰撞次数" v={s.crashes} c="text-red-300" />
          <Row k="总里程" v={`${Math.round(s.distance / 1000)} km`} />
        </div>
      </div>
      <div>
        <div className="mb-1 text-[10px] tracking-widest text-white/50 uppercase">成就（{save.achievements.length}/{ACHIEVEMENTS.length}）</div>
        <div className="max-h-32 space-y-1 overflow-y-auto pr-1">
          {ACHIEVEMENTS.map((a) => {
            const got = save.achievements.includes(a.id);
            return (
              <div key={a.id} className={cn("flex items-center gap-1.5 rounded-md border px-1.5 py-1", got ? "border-amber-400/40 bg-amber-400/10" : "border-white/10 bg-white/4 opacity-60")}>
                <Trophy className={cn("h-3 w-3 shrink-0", got ? "text-amber-300" : "text-white/30")} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[10px] font-bold text-white">{a.name}</div>
                  <div className="truncate text-[9px] text-white/45">{a.desc}</div>
                </div>
                <span className="shrink-0 text-[9px] text-amber-300">+{a.reward}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Row({ k, v, c }: { k: string; v: string | number; c?: string }) {
  return (
    <div className="flex justify-between">
      <span>{k}</span>
      <span className={c ?? "text-white"}>{v}</span>
    </div>
  );
}

// ------------------------------------------------------------------ 房间排行榜
export function RoomBoard({ save, room, track }: { save: SaveData; room: string; track: string }) {
  const key = `${room}:${track}`;
  const list = (save.rooms[key] ?? []).slice().sort((a, b) => a.time - b.time);
  return (
    <div>
      <div className="mb-1 flex items-center gap-1 text-[10px] tracking-widest text-white/50 uppercase">
        <Users className="h-3 w-3" /> 房间 {room} 排行榜
      </div>
      {list.length === 0 ? (
        <div className="rounded-lg border border-white/10 bg-white/5 p-2 text-[10px] text-white/40">还没有成绩，跑完一局后自动记录。把房间号发给好友，比拼同一赛道成绩。</div>
      ) : (
        <div className="space-y-0.5 rounded-lg border border-white/10 bg-white/5 p-2">
          {list.slice(0, 6).map((r, i) => (
            <div key={r.name + i} className="flex items-center gap-1.5 font-mono text-[10px]">
              <span className={cn("w-4 text-right font-black", i === 0 ? "text-amber-300" : "text-white/40")}>{i + 1}</span>
              <span className="flex-1 truncate font-sans text-white/80">{r.name}</span>
              <span className="text-cyan-300">P{r.position}</span>
              <span className="text-white/70">{fmtTime(r.time)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function fmtTime(t: number) {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  const ms = Math.floor((t * 1000) % 1000);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String(ms).padStart(3, "0")}`;
}

// ------------------------------------------------------------------ 道具图鉴
export function ItemCodex() {
  return (
    <div>
      <div className="mb-1 flex items-center gap-1 text-[10px] tracking-widest text-white/50 uppercase">
        <Package className="h-3 w-3" /> 道具图鉴（名次越靠后越容易吃到强道具）
      </div>
      <div className="grid grid-cols-3 gap-1">
        {ITEM_LIST.map((it) => (
          <div key={it.id} className="flex items-center gap-1 rounded-md border border-white/10 bg-white/5 px-1.5 py-1">
            <span className="text-sm">{it.emoji}</span>
            <div className="min-w-0">
              <div className="truncate text-[9px] font-bold text-white">{it.name}</div>
              <div className="truncate text-[8px] text-white/40">{it.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
