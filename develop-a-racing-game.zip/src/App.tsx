import Race3D from "./components/Race3D";
import { Boxes, Car, Film, Heart, Route, Sparkles } from "lucide-react";

const FEATURES = [
  { icon: Boxes, color: "text-cyan-300", title: "真 3D 引擎", body: "Three.js 实时渲染：金属车漆 PBR 反射、动态阴影、HDR 环境光、赛道倾斜与坡度，跟车镜头随速度拉伸 FOV。" },
  { icon: Heart, color: "text-rose-400", title: "车况血量", body: "冲出赛道不再瞬间重置。缓冲区撞到树木岩石才扣血，回到赛道自动修复；血量归零才会拖回赛道并短暂无敌。" },
  { icon: Car, color: "text-amber-300", title: "刚体防穿模", body: "8 台车在弧长-横向空间做刚体分离，任意两车永不重叠。追尾会真实推挤：后车泄速、前车被顶出去。" },
  { icon: Route, color: "text-lime-300", title: "5 张异形赛道", body: "高速椭圆、三叶草技术弯、荒漠发夹、大落差雪山、悬空 8 字。可选短程 1 圈冲刺或长程 3 圈耐力。" },
  { icon: Sparkles, color: "text-fuchsia-400", title: "6 车型 × 10 涂装", body: "B/A/S/T 四个品级，从入门 GT 到 T 级「引擎之心」机甲。10 种车漆 × 10 种涂装图案，车库 3D 转台实时预览。" },
  { icon: Film, color: "text-purple-300", title: "电影级入场", body: "开赛前高空环绕俯冲到车尾的运镜，配赛道名、赛制与车辆信息展示，随后进入 3-2-1 倒计时。" },
];

export default function App() {
  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_#3b1d5e_0%,_#140b22_55%,_#07040d_100%)] px-3 py-5 text-white sm:px-6 sm:py-8">
      <div className="mx-auto max-w-5xl">
        <header className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-pink-500 to-orange-400 shadow-lg shadow-pink-500/30">
              <Car className="h-6 w-6" />
            </div>
            <div>
              <div className="text-lg leading-tight font-black tracking-tight">落日狂飙 3D · Sunset GP</div>
              <div className="text-xs text-white/50">Three.js 真 3D · 车况血量 · 刚体防穿模 · 入场运镜</div>
            </div>
          </div>
          <div className="hidden text-xs text-white/40 sm:block">WASD 驾驶 · Shift 漂移 · 空格 氮气 · Q 道具 · P 暂停</div>
        </header>

        <Race3D />

        <footer className="mt-6 grid gap-3 text-xs text-white/50 sm:grid-cols-3">
          {FEATURES.map((f) => {
            const Icon = f.icon;
            return (
              <div key={f.title} className="rounded-xl border border-white/10 bg-white/5 p-3">
                <div className="mb-1 flex items-center gap-1.5 font-semibold text-white/80">
                  <Icon className={`h-3.5 w-3.5 ${f.color}`} />
                  {f.title}
                </div>
                {f.body}
              </div>
            );
          })}
        </footer>

        <div className="mt-4 rounded-xl border border-cyan-400/20 bg-cyan-400/5 p-3 text-xs leading-relaxed text-white/60">
          <span className="font-bold text-cyan-300">组合喷连招</span>：入弯按住 <kbd className="rounded bg-white/15 px-1 font-mono">Shift</kbd> 漂移集气 → 漂移中反打方向<b className="text-white/80">拉头</b>贴弯 → 漂移途中按{" "}
          <kbd className="rounded bg-white/15 px-1 font-mono">空格</kbd> 装填 <b className="text-white/80">WC 喷</b> → 出弯瞬间叠加爆发 → 判定条亮起时再点 Shift 打出 <b className="text-white/80">完美双喷</b> →
          喷射尾段接氮气形成 <b className="text-white/80">LINK 喷</b>。跳台腾空时按住油门可触发 <b className="text-white/80">落地喷</b>，一套连下来能连吃五段加速。
        </div>
      </div>
    </div>
  );
}
